/*
 * script_engine.h
 *
 *  Created on: Jun 8, 2025
 *      Author: Ghaith
 */
#include "stm32f4xx_hal.h"
#ifndef INC_SCRIPT_ENGINE_H_
#define INC_SCRIPT_ENGINE_H_


//#define LUA_MEM_LIMIT (8 * 1024)  // try 8*1024 or more depending on your RAM
#define LUA_MEM_LIMIT (32 * 1024)       // Total Lua heap limit (adjust as needed)
#define MAX_ALLOC_BLOCK 2048          // Optional: maximum single block allowed (optional)
//#define LUA_MEM_LIMIT 20 * 1024  // 20 KB
#define LUA_QUEUE_SIZE 200


#define SCRIPT_BUF_SIZE 2000
#define INITIAL_ALLOC 512
#define ALLOC_STEP    256
#define MAX_SCRIPT_SIZE 2000  // Optional upper limit




#endif /* INC_SCRIPT_ENGINE_H_ */
