#include "main.h"
#include "cmsis_os.h"
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include "script_engine.h"
#include <string.h>
#include <stdlib.h>
#include <float.h>
#include <math.h>

extern osMessageQueueId_t protocolQueues[NUM_PROTOCOLS];
extern UART_HandleTypeDef huart2;
extern I2C_HandleTypeDef hi2c1;
extern SPI_HandleTypeDef hspi1;
extern CAN_HandleTypeDef hcan1;

extern  lua_State *L;



extern void Set_Pin_Input(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
extern void Set_Pin_Output(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin);
extern void delay_us(uint16_t us);
extern void process_command(char *cmd);

int lua_read_pin(lua_State *L) ;
int lua_spi_send(lua_State *L) ;
int lua_spi_transfer(lua_State *L);
int lua_can_filter(lua_State *L);
int lua_can_send(lua_State *L);
int lua_can_send_ext(lua_State *L);
int lua_i2c_send(lua_State *L);
int lua_i2c_mem_write(lua_State *L);
int lua_i2c_read(lua_State *L);
int lua_i2c_mem_read(lua_State *L) ;
int lua_write_pin(lua_State *L) ;
int lua_set_pin_mode(lua_State *L);
int send_message(lua_State *L);
int lua_get(lua_State *L) ;
int configure_system(lua_State *L);
int lua_print(lua_State *L) ;
int lua_delay_ms(lua_State *L);
int lua_delay_us(lua_State *L) ;
int lua_delay_ms_NB(lua_State *L);
