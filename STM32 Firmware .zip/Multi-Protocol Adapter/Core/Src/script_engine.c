#include "main.h"
#include "cmsis_os.h"
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
#include "script_engine.h"
#include <string.h>
#include <stdlib.h>
#include "Lua_API.h"

#define BOOT_MSG(msg) HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 100)

uint8_t lua_protocol_filter[NUM_PROTOCOLS] = { 0 };

extern osMessageQueueId_t luaQueueHandle;
lua_State *L = NULL;
static osThreadId_t LuaTaskHandle = NULL;

// Script buffer management
static char *script_buf = NULL;
static size_t script_capacity = 0;
static uint32_t script_pos = 0;
static volatile uint32_t script_len = 0;
static volatile uint8_t script_ready = 0;
uint8_t collecting = 0;
extern volatile  uint8_t script_runing;
static volatile uint8_t stop_requested = 0;

// Memory management
#define MEM_CHECK_INTERVAL 1000
#define GC_THRESHOLD 0.7
#define EMERGENCY_THRESHOLD 0.85

// Forward declarations
static void StartLuaTask(void *argument);
static void register_lua_api(void);
void ScriptEngine_Reset(void);
size_t get_lua_mem_usage(void);

// ===================== Memory Management =====================
size_t get_lua_mem_usage(void) {
    if (!L) return 0;
    return lua_gc(L, LUA_GCCOUNT, 0) * 1024 + lua_gc(L, LUA_GCCOUNTB, 0);
}

static void* lua_alloc(void *ud, void *ptr, size_t osize, size_t nsize) {
    (void)ud;

    if (nsize == 0) {
        free(ptr);
        return NULL;
    }

    // Safe allocation without complex checks during init
    return realloc(ptr, nsize);
}

void check_memory_pressure(void) {
    if (!L) return;

    static uint32_t last_check = 0;
    uint32_t now = HAL_GetTick();

    if (now - last_check < MEM_CHECK_INTERVAL) return;
    last_check = now;

    size_t usage = get_lua_mem_usage();
    if (usage > LUA_MEM_LIMIT * EMERGENCY_THRESHOLD) {
        lua_gc(L, LUA_GCSTOP, 0);
        lua_gc(L, LUA_GCCOLLECT, 0);
        lua_gc(L, LUA_GCRESTART, 0);
    }
    else if (usage > LUA_MEM_LIMIT * GC_THRESHOLD) {
        lua_gc(L, LUA_GCCOLLECT, 0);
    }
}

// ===================== Lua API Registration =====================
static void register_lua_api(void) {
	lua_register(L, "print", lua_print);
	lua_register(L, "send_message", send_message);
	lua_register(L, "configure_system", configure_system);
	lua_register(L, "get", lua_get);  // NEW: Register the get() API
	lua_register(L, "delay_ms", lua_delay_ms_NB);
	lua_register(L, "delay_ms_B", lua_delay_ms);
	lua_register(L, "delay_us", lua_delay_us);
	lua_register(L, "read_pin", lua_read_pin);
	lua_register(L, "write_pin", lua_write_pin);
	lua_register(L, "set_pin_mode", lua_set_pin_mode);
	lua_register(L, "i2c_send", lua_i2c_send);
	lua_register(L, "i2c_mem_write", lua_i2c_mem_write);
	lua_register(L, "i2c_read", lua_i2c_read);
	lua_register(L, "i2c_mem_read", lua_i2c_mem_read);
	lua_register(L, "spi_transfer", lua_spi_transfer);
	lua_register(L, "spi_send", lua_spi_send);
	lua_register(L, "can_send", lua_can_send);
	lua_register(L, "can_filter", lua_can_filter);
	lua_register(L, "can_send_ext", lua_can_send_ext);

	// Register protocol constants globally
	lua_pushinteger(L, UART);
	lua_setglobal(L, "UART");

	lua_pushinteger(L, SPI);
	lua_setglobal(L, "SPI");

	lua_pushinteger(L, I2C);
	lua_setglobal(L, "I2C");

	lua_pushinteger(L, CAN);
	lua_setglobal(L, "CAN");

	lua_pushinteger(L, COM);
	lua_setglobal(L, "COM");

	char msg[64];
	snprintf(msg, sizeof(msg), "register_lua_api L: %p\n", (void*) L);
	HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), 200);

}
// ===================== Engine Control =====================
void ScriptEngine_Stop(void) {
    stop_requested = 1;
}

void ScriptEngine_Reset(void) {
    BOOT_MSG("[LUA] Resetting engine\r\n");

    // Close Lua state safely
    if (L) {
        lua_close(L);
        L = NULL;
    }

    // Reset script state
    script_runing = 0;
    script_ready = 0;
    collecting = 0;
    stop_requested = 0;

    // Free script buffer
    if (script_buf) {
        free(script_buf);
        script_buf = NULL;
    }
    script_capacity = 0;
    script_pos = 0;
    script_len = 0;

    // Reinitialize Lua state
    L = lua_newstate(lua_alloc, NULL);
    if (L) {
        BOOT_MSG("[LUA] State created\r\n");
        luaL_openlibs(L);
        register_lua_api();
    } else {
        BOOT_MSG("[LUA] State creation FAILED\r\n");
    }
}

void ScriptEngine_Init(void) {
    BOOT_MSG("[LUA] Initializing\r\n");

    // Create message queue FIRST
//    luaQueueHandle = osMessageQueueNew(LUA_QUEUE_SIZE, sizeof(LuaMessage), NULL);
//    if (!luaQueueHandle) {
//        BOOT_MSG("[LUA] Queue creation FAILED\r\n");
//    }

    // Create Lua task with larger stack
    const osThreadAttr_t LuaTask_attributes = {
        .name = "LuaTask",
        .stack_size = 4096 * 4,  // 16KB stack
        .priority = osPriorityNormal,  // Lower priority
    };

    LuaTaskHandle = osThreadNew(StartLuaTask, NULL, &LuaTask_attributes);
    if (!LuaTaskHandle) {
        BOOT_MSG("[LUA] Task creation FAILED\r\n");
    }

    // Initialize engine (creates Lua state)
    ScriptEngine_Reset();

    BOOT_MSG("[LUA] Init complete\r\n");
}

// ===================== UART Handler =====================
void Script_UART2_RxHandler(uint8_t byte) {
    if (!collecting && byte == '$') {
        collecting = 1;
        script_pos = 0;
        script_ready = 0;

        if (script_buf) {
            free(script_buf);
            script_buf = NULL;
        }

        script_capacity = INITIAL_ALLOC;
        script_buf = malloc(script_capacity);
        if (!script_buf) {
            collecting = 0;
            return;
        }
        return;
    }

    if (collecting && script_buf) {
        if (byte == '$') {
            collecting = 0;
            script_len = script_pos;
            script_ready = 1;
            script_runing = 1;
            return;
        }

        if (script_pos >= script_capacity) {
            size_t new_capacity = script_capacity + ALLOC_STEP;
            if (new_capacity > MAX_SCRIPT_SIZE) {
                free(script_buf);
                script_buf = NULL;
                collecting = 0;
                return;
            }

            char *new_buf = realloc(script_buf, new_capacity);
            if (!new_buf) {
                free(script_buf);
                script_buf = NULL;
                collecting = 0;
                return;
            }
            script_buf = new_buf;
            script_capacity = new_capacity;
        }

        script_buf[script_pos++] = byte;
    }
}

// ===================== Main Task =====================
void StartLuaTask(void *argument) {
    BOOT_MSG("[LUA] Task started\r\n");

    int message_handler_ref = LUA_NOREF;

    for (;;) {
        if (stop_requested) {
            BOOT_MSG("[LUA] Stop requested\r\n");
            ScriptEngine_Reset();
            osDelay(100);
            continue;
        }

        if (script_ready == 1) {
            BOOT_MSG("[LUA] Loading script\r\n");

            if (L && luaL_loadbuffer(L, script_buf, script_len, "main") == LUA_OK) {
                if (lua_pcall(L, 0, 0, 0) == LUA_OK) {
                    lua_getglobal(L, "handle_message");
                    if (lua_isfunction(L, -1)) {
                        message_handler_ref = luaL_ref(L, LUA_REGISTRYINDEX);
                        BOOT_MSG("[LUA] Handler registered\r\n");
                    } else {
                        lua_pop(L, 1);
                        message_handler_ref = LUA_NOREF;
                    }
                }
            }

            if (script_buf) {
                free(script_buf);
                script_buf = NULL;
            }
            script_capacity = 0;
            script_pos = 0;
            script_len = 0;
            script_ready = 2;
        }

        if (script_ready == 2) {
            LuaMessage lua_msg;
            if (osMessageQueueGet(luaQueueHandle, &lua_msg, NULL, osWaitForever) == osOK) {
                if (message_handler_ref != LUA_NOREF) {
                    lua_rawgeti(L, LUA_REGISTRYINDEX, message_handler_ref);

                    if (lua_isfunction(L, -1)) {
                        lua_pushinteger(L, lua_msg.protocol);
                        lua_pushlstring(L, (const char*)lua_msg.data, lua_msg.len);

                        if (lua_pcall(L, 2, 0, 0) != LUA_OK) {
                            lua_pop(L, 1); // Pop error
                        }
                    } else {
                        lua_pop(L, 1);
                    }
                }

                // Perform incremental GC
                lua_gc(L, LUA_GCSTEP, 50);
            }
        }
        else {
            osDelay(10);
        }
    }
}
