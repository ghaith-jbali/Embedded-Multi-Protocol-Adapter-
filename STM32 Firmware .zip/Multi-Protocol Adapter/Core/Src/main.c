/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 * ⠛⠓⠁⠊⠞⠓ ⠚⠑⠃⠁⠇⠊
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>  // for strtoul
#include "script_engine.h"
#include "Lua_API.h"

extern uint8_t uart2_rx_byte;

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
typedef StaticQueue_t osStaticMessageQDef_t;
/* USER CODE BEGIN PTD */

const ProtocolLookup protocol_map[] = { { "UART", UART }, { "SPI", SPI }, {
		"I2C", I2C }, { "CAN", CAN }, { "COM", COM } };

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan1;

I2C_HandleTypeDef hi2c1;
DMA_HandleTypeDef hdma_i2c1_tx;
DMA_HandleTypeDef hdma_i2c1_rx;

IWDG_HandleTypeDef hiwdg;

SPI_HandleTypeDef hspi1;
DMA_HandleTypeDef hdma_spi1_rx;
DMA_HandleTypeDef hdma_spi1_tx;

TIM_HandleTypeDef htim7;

UART_HandleTypeDef huart4;
UART_HandleTypeDef huart1;
UART_HandleTypeDef huart2;
UART_HandleTypeDef huart3;
DMA_HandleTypeDef hdma_uart4_rx;
DMA_HandleTypeDef hdma_uart4_tx;
DMA_HandleTypeDef hdma_usart1_rx;
DMA_HandleTypeDef hdma_usart1_tx;
DMA_HandleTypeDef hdma_usart2_tx;
DMA_HandleTypeDef hdma_usart2_rx;
DMA_HandleTypeDef hdma_usart3_rx;
DMA_HandleTypeDef hdma_usart3_tx;

/* Definitions for BEGINTask */
osThreadId_t BEGINTaskHandle;
const osThreadAttr_t BEGINTask_attributes = {
  .name = "BEGINTask",
  .stack_size = 200 * 4,
  .priority = (osPriority_t) osPriorityRealtime,
};
/* Definitions for CANTask */
osThreadId_t CANTaskHandle;
const osThreadAttr_t CANTask_attributes = {
  .name = "CANTask",
  .stack_size = 200 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for UARTTask */
osThreadId_t UARTTaskHandle;
const osThreadAttr_t UARTTask_attributes = {
  .name = "UARTTask",
  .stack_size = 200 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for SPITask */
osThreadId_t SPITaskHandle;
const osThreadAttr_t SPITask_attributes = {
  .name = "SPITask",
  .stack_size = 200 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for I2CTask */
osThreadId_t I2CTaskHandle;
const osThreadAttr_t I2CTask_attributes = {
  .name = "I2CTask",
  .stack_size = 200 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for LEDTask */
osThreadId_t LEDTaskHandle;
const osThreadAttr_t LEDTask_attributes = {
  .name = "LEDTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for ConfigTask */
osThreadId_t ConfigTaskHandle;
const osThreadAttr_t ConfigTask_attributes = {
  .name = "ConfigTask",
  .stack_size = 256 * 4,
  .priority = (osPriority_t) osPriorityHigh,
};
/* Definitions for COMTask */
osThreadId_t COMTaskHandle;
const osThreadAttr_t COMTask_attributes = {
  .name = "COMTask",
  .stack_size = 160 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for myQueue01 */
osMessageQueueId_t myQueue01Handle;
uint8_t myQueue01Buffer[ 16 * sizeof( uint16_t ) ];
osStaticMessageQDef_t myQueue01ControlBlock;
const osMessageQueueAttr_t myQueue01_attributes = {
  .name = "myQueue01",
  .cb_mem = &myQueue01ControlBlock,
  .cb_size = sizeof(myQueue01ControlBlock),
  .mq_mem = &myQueue01Buffer,
  .mq_size = sizeof(myQueue01Buffer)
};
/* Definitions for uartTxSemaphore */
osSemaphoreId_t uartTxSemaphoreHandle;
const osSemaphoreAttr_t uartTxSemaphore_attributes = {
  .name = "uartTxSemaphore"
};
/* Definitions for spiTxSemaphore */
osSemaphoreId_t spiTxSemaphoreHandle;
const osSemaphoreAttr_t spiTxSemaphore_attributes = {
  .name = "spiTxSemaphore"
};
/* Definitions for i2cTxSemaphore */
osSemaphoreId_t i2cTxSemaphoreHandle;
const osSemaphoreAttr_t i2cTxSemaphore_attributes = {
  .name = "i2cTxSemaphore"
};
/* Definitions for uart3TxSemaphore */
osSemaphoreId_t uart3TxSemaphoreHandle;
const osSemaphoreAttr_t uart3TxSemaphore_attributes = {
  .name = "uart3TxSemaphore"
};
/* Definitions for canTxSemaphore */
osSemaphoreId_t canTxSemaphoreHandle;
const osSemaphoreAttr_t canTxSemaphore_attributes = {
  .name = "canTxSemaphore"
};
/* Definitions for uart2TxSemaphore */
osSemaphoreId_t uart2TxSemaphoreHandle;
const osSemaphoreAttr_t uart2TxSemaphore_attributes = {
  .name = "uart2TxSemaphore"
};
/* Definitions for uart4TxSemaphore */
osSemaphoreId_t uart4TxSemaphoreHandle;
const osSemaphoreAttr_t uart4TxSemaphore_attributes = {
  .name = "uart4TxSemaphore"
};
/* Definitions for ConfigEvent */
osEventFlagsId_t ConfigEventHandle;
const osEventFlagsAttr_t ConfigEvent_attributes = {
  .name = "ConfigEvent"
};
/* USER CODE BEGIN PV */

// --- For protocolQueues ---
// Buffer for the internal control block of each protocol queue
// Using the exact type from CubeMX output: osStaticMessageQDef_t
static osStaticMessageQDef_t protocolQueues_cb[NUM_PROTOCOLS];
// Buffer for messages stored in each protocol queue
static uint8_t protocolQueues_buf[NUM_PROTOCOLS][PROTOCOLS_QUEUE_SIZE * sizeof(IncomingMessage)];

// --- For luaQueueHandle ---
// Buffer for the internal control block of the Lua queue
static osStaticMessageQDef_t luaQueueHandle_cb;
// Buffer for messages stored in the Lua queue
static uint8_t luaQueueHandle_buf[LUA_QUEUE_SIZE * sizeof(LuaMessage)];


// === Queues ===
osMessageQueueId_t protocolQueues[NUM_PROTOCOLS];
osMessageQueueId_t luaQueueHandle;

// === Routing ===
extern   uint8_t lua_protocol_filter[NUM_PROTOCOLS];
volatile uint8_t RoutingMatrix[NUM_PROTOCOLS][NUM_PROTOCOLS];
char cmd_buffer[MAX_CMD_LEN];

// === CAN Configuration ===
uint16_t CAN_prescaler = 16;
uint8_t CAN_time_seg1 = 13;
uint8_t CAN_time_seg2 = 2;
uint16_t CAN_msg_id = 0x01;
uint16_t CAN_filter_id = 0x000;
uint16_t CAN_filter_mask = 0x000;
uint8_t can_tx_size = 2;
static uint8_t can_tx_buffer[100];
static size_t can_buffer_length = 0;

// === SPI Configuration ===
uint8_t SPI_mode = 0;  // 0 = master, 1 = slave
uint32_t SPI_prescaler = 256;
uint32_t SPI_cpol = 0;
uint32_t SPI_cpha = 0;
uint32_t SPI_data_size = 8;
uint32_t SPI_bit_order = 0;
uint8_t SPI_rx_size = 1;
uint8_t SPI_tx_size = 2;

uint8_t spi_txrx_buffer[32];
uint8_t spi_txrx_len;
uint8_t spi_rx_byte[32];
static uint8_t spi_tx_buffer[100];
static size_t spi_buffer_length = 0;

// === UART Configuration ===
UART_InitTypeDef uart_cfg;
uint32_t uart_baudrate = 115200;
uint16_t uart_wordlength = UART_WORDLENGTH_8B;
uint16_t uart_stopbits = UART_STOPBITS_1;
uint16_t uart_parity = UART_PARITY_NONE;

uint8_t uart1_rx_byte[32];
uint8_t UART_rx_size = 1;
uint8_t UART_tx_size = 1;
static uint8_t uart_tx_buffer[100];
static size_t uart_buffer_length = 0;

// === UART2 Command Parsing ===
uint8_t uart2_rx_byte;
uint8_t uart2_rx_buffer[MAX_CMD_LEN];
uint8_t uart2_rx_len = 0;
uint8_t collecting_cmd = 0;

// === I2C Configuration ===
uint16_t I2C_slave_addr = 0x00;
uint32_t I2C_speed = 100000;
uint8_t I2C_mode = 0;  // 0 = Master write, 1 = Master read ,2 = Master read from mem , 3 = Slave
uint8_t I2C_read_size = 1;
uint8_t I2C_tx_size = 2;
uint8_t I2C_own_addr;
uint8_t I2C_mem_addr;

uint8_t i2c_rx_byte[32];
static uint8_t i2c_tx_buffer[100];
static size_t i2c_buffer_len = 0;

// === Lua/Script State ===
extern uint8_t collecting ;
volatile uint8_t script_runing = 0;
uint8_t collecting_script = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_DMA_Init(void);
static void MX_CAN1_Init(void);
static void MX_I2C1_Init(void);
static void MX_SPI1_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_USART1_UART_Init(void);
static void MX_UART4_Init(void);
static void MX_USART3_UART_Init(void);
static void MX_TIM7_Init(void);
static void MX_IWDG_Init(void);
void StartBEGINTask(void *argument);
void StartCANTask(void *argument);
void StartUARTTask(void *argument);
void StartSPITask(void *argument);
void StartI2CTask(void *argument);
void StartLEDTask(void *argument);
void StartConfigTask(void *argument);
void StartCOMTask(void *argument);

/* USER CODE BEGIN PFP */
void CAN_Init(void);
void InitRoutingMatrix(void);
void InitQueues(void);
void SetRoutingRule(ProtocolType from, ProtocolType to, uint8_t value);
void SetBridingRule(ProtocolType from, ProtocolType to, uint8_t value);
void process_command(char *cmd);
ProtocolType get_protocol_from_name(const char *name);
void ClearAllQueuesAndBuffers(void);
extern void ScriptEngine_Init(void);
extern void Script_UART2_RxHandler(uint8_t byte);
extern void ScriptEngine_Stop(void);
int _gettimeofday(struct timeval *tv, void *tz) {
	return 0; // Dummy implementation
}
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart) {

	if ((huart->Instance == USART2) || (huart->Instance == USART3)
			|| (huart->Instance == UART4)) {

		// === 1. SCRIPT MODE ===
		if (collecting_script) {
			Script_UART2_RxHandler(uart2_rx_byte);

			if (!collecting) {
				// Script just finished
				collecting_script = 0;
			}
		}

		// === 2. COMMAND MODE ===
		else if (collecting_cmd) {
			if (uart2_rx_byte == '\n' || uart2_rx_byte == '\r') {
				uart2_rx_buffer[uart2_rx_len] = '\0';
				strncpy(cmd_buffer, (char*) uart2_rx_buffer, uart2_rx_len);
				cmd_buffer[uart2_rx_len] = '\0';
				uart2_rx_len = 0;
				collecting_cmd = 0;

				HAL_UART_Abort_IT(&huart2);
				HAL_UART_Abort_IT(&huart3);
				HAL_UART_Abort_IT(&huart4);

				osEventFlagsSet(ConfigEventHandle, 0x01);
			} else {
				if (uart2_rx_len < MAX_CMD_LEN - 1) {
					uart2_rx_buffer[uart2_rx_len++] = uart2_rx_byte;
				} else {
					collecting_cmd = 0;
					uart2_rx_len = 0;
				}
			}
		}

		// === 3. START SCRIPT COLLECTION ===
		else if (uart2_rx_byte == '$') {
			collecting_script = 1;
			Script_UART2_RxHandler('$');
		}

		// === 4. START COMMAND COLLECTION ===
		else if (uart2_rx_byte == '@') {
			collecting_cmd = 1;
			uart2_rx_len = 0;
		}

		// === 5. FORWARD MESSAGE BYTE ===
		else {
			if (script_runing && lua_protocol_filter[COM]) {
				// Forward to Lua queue
				LuaMessage lua_msg = { .protocol = COM, .len = UART_rx_size,
						.data[0] = uart2_rx_byte, };

				osMessageQueuePut(luaQueueHandle, &lua_msg, 0, 0);
			} else {
				IncomingMessage msg;
				msg.data[0] = uart2_rx_byte;
				msg.len = 1;
				for (int to = 0; to < NUM_PROTOCOLS; to++) {
					if (RoutingMatrix[COM][to]) {
						osMessageQueuePut(protocolQueues[to], &msg, 0, 0);

					}
				}
			}
		}

		// === 6. RE-ARM DMA ===
		HAL_UART_Receive_DMA(&huart2, &uart2_rx_byte, 1);
		HAL_UART_Receive_DMA(&huart3, &uart2_rx_byte, 1);
		HAL_UART_Receive_DMA(&huart4, &uart2_rx_byte, 1);

		HAL_GPIO_TogglePin(COM_LED_GPIO_Port, COM_LED_Pin);
	}

	if (huart->Instance == USART1) {

		if (script_runing && lua_protocol_filter[UART]) { // Check if Lua is active
			LuaMessage lua_msg = { .protocol = UART, .len = UART_rx_size, };
			memcpy(lua_msg.data, uart1_rx_byte, UART_rx_size);
			osMessageQueuePut(luaQueueHandle, &lua_msg, 0, 0);
		} else {
			IncomingMessage msg;
			msg.len = UART_rx_size;
			memcpy(msg.data, uart1_rx_byte, UART_rx_size);
			for (int to = 0; to < NUM_PROTOCOLS; to++) {
				if (RoutingMatrix[UART][to]) {
					osMessageQueuePut(protocolQueues[to], &msg, 0, 0);
				}
			}
		}
		HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
		HAL_UART_Receive_DMA(&huart1, uart1_rx_byte, UART_rx_size);

	}
}

void HAL_CAN_RxFifo0MsgPendingCallback(CAN_HandleTypeDef *hcan) {
	CAN_RxHeaderTypeDef can_rx;
	uint8_t rx_data[8];

	if (HAL_CAN_GetRxMessage(hcan, CAN_RX_FIFO0, &can_rx, rx_data) == HAL_OK) {

		if (script_runing && lua_protocol_filter[CAN]) {
			// Forward to Lua queue
			LuaMessage lua_msg = { .protocol = CAN, .len = can_rx.DLC, };
			memcpy(lua_msg.data, rx_data, can_rx.DLC);
			osMessageQueuePut(luaQueueHandle, &lua_msg, 0, 0);
		} else {
			// Normal routing
			IncomingMessage msg = { .len = can_rx.DLC };
					memcpy(msg.data, rx_data, can_rx.DLC);
			for (int to = 0; to < NUM_PROTOCOLS; to++) {
				if (RoutingMatrix[CAN][to]) {
					osMessageQueuePut(protocolQueues[to], &msg, 0, 0);
				}
			}
		}
		HAL_GPIO_TogglePin(GPIOC, LED2_Pin);
	}
}

void HAL_I2C_MasterRxCpltCallback(I2C_HandleTypeDef *hi2c) {

	if (script_runing && lua_protocol_filter[I2C]) {
		// Forward to Lua queue
		LuaMessage lua_msg = { .protocol = I2C, .len = I2C_read_size, };
		memcpy(lua_msg.data, i2c_rx_byte, I2C_read_size);
		osMessageQueuePut(luaQueueHandle, &lua_msg, 0, 0);
	} else {
		IncomingMessage msg;
		msg.len = I2C_read_size;
		memcpy(msg.data, i2c_rx_byte, I2C_read_size);
		for (int to = 0; to < NUM_PROTOCOLS; to++) {
			if (RoutingMatrix[I2C][to]) {
				osMessageQueuePut(protocolQueues[to], &msg, 0, 0);
			}
		}
	}
	HAL_GPIO_TogglePin(GPIOC, LED3_Pin);

}

void HAL_I2C_SlaveRxCpltCallback(I2C_HandleTypeDef *hi2c) {

	if (script_runing && lua_protocol_filter[I2C]) {
		LuaMessage lua_msg = { .protocol = I2C, .len = I2C_read_size, };
		memcpy(lua_msg.data, i2c_rx_byte, I2C_read_size);
		osMessageQueuePut(luaQueueHandle, &lua_msg, 0, 0);
	} else {
		IncomingMessage msg;
		msg.len = I2C_read_size;
		memcpy(msg.data, i2c_rx_byte, I2C_read_size);
		for (int to = 0; to < NUM_PROTOCOLS; to++) {
			if (RoutingMatrix[I2C][to]) {
				osMessageQueuePut(protocolQueues[to], &msg, 0, 0) ;
			}
		}
	}
	HAL_GPIO_TogglePin(GPIOD, LED4_Pin);
	HAL_I2C_Slave_Receive_DMA(&hi2c1, i2c_rx_byte, I2C_read_size);

}

void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi) {

	if (script_runing && lua_protocol_filter[SPI]) {
		LuaMessage lua_msg = { .protocol = SPI, .len = SPI_rx_size, };
		memcpy(lua_msg.data, spi_rx_byte, SPI_rx_size);
		osMessageQueuePut(luaQueueHandle, &lua_msg, 0, 0);
	} else {
		IncomingMessage msg;
		msg.len = SPI_rx_size;
		memcpy(msg.data, spi_rx_byte, SPI_rx_size);

		for (int to = 0; to < NUM_PROTOCOLS; to++) {
			if (RoutingMatrix[SPI][to]) {
				osMessageQueuePut(protocolQueues[to], &msg, 0, 0) ;
			}
		}
	}
	if (SPI_mode == 2) {
		HAL_SPI_Receive_DMA(&hspi1, spi_rx_byte, SPI_rx_size);
	}
	HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin);

}

void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi) {

	if (script_runing && lua_protocol_filter[SPI]) {
		LuaMessage lua_msg = { .protocol = SPI, .len = spi_txrx_len, };
		memcpy(lua_msg.data, spi_rx_byte, spi_txrx_len);
		osMessageQueuePut(luaQueueHandle, &lua_msg, 0, 0);
	} else {

		IncomingMessage msg;
		msg.len = spi_txrx_len;
		memcpy(msg.data, spi_rx_byte, spi_txrx_len);
		for (int to = 0; to < NUM_PROTOCOLS; to++) {
			if (RoutingMatrix[SPI][to]) {
				osMessageQueuePut(protocolQueues[to], &msg, 0, 0);
			}
		}
	}
	osSemaphoreRelease(spiTxSemaphoreHandle);

}

void HAL_UART_TxCpltCallback(UART_HandleTypeDef *huart) {
	if (huart == &huart1) {
		osSemaphoreRelease(uartTxSemaphoreHandle); // Signal task that UART is free
	}
	if (huart == &huart2) {
		osSemaphoreRelease(uart2TxSemaphoreHandle); // Signal task that UART is free
	}
	if (huart == &huart3) {
		osSemaphoreRelease(uart3TxSemaphoreHandle); // Signal task that UART is free
	}
	if (huart == &huart4) {
		osSemaphoreRelease(uart4TxSemaphoreHandle); // Signal task that UART is free
	}
}

void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi) {

	osSemaphoreRelease(spiTxSemaphoreHandle);
}

void HAL_I2C_MasterTxCpltCallback(I2C_HandleTypeDef *hi2c) {

	osSemaphoreRelease(i2cTxSemaphoreHandle);
}

void HAL_I2C_ErrorCallback(I2C_HandleTypeDef *hi2c) {
    __HAL_I2C_CLEAR_FLAG(&hi2c1, I2C_FLAG_BERR | I2C_FLAG_ARLO | I2C_FLAG_AF);
    hi2c1.State = HAL_I2C_STATE_READY; // force recover
	osSemaphoreRelease(i2cTxSemaphoreHandle);
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	InitRoutingMatrix();
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  SystemCoreClockUpdate();
  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_CAN1_Init();
  MX_I2C1_Init();
  MX_SPI1_Init();
  MX_USART2_UART_Init();
  MX_USART1_UART_Init();
  MX_UART4_Init();
  MX_USART3_UART_Init();
  MX_TIM7_Init();
  MX_IWDG_Init();
  /* USER CODE BEGIN 2 */
  HAL_TIM_Base_Start(&htim7);

	CAN_Init();

	HAL_UART_Receive_DMA(&huart1, uart1_rx_byte, UART_rx_size);
	HAL_UART_Receive_DMA(&huart2, &uart2_rx_byte, 1);
	HAL_UART_Receive_DMA(&huart3, &uart2_rx_byte, 1);

	/*HAL_SPI_Receive_DMA(&hspi1, &spi_rx_byte, 1);
	 HAL_I2C_Master_Receive_DMA(&hi2c1, I2C_add, &i2c_m_rx_byte, 1);
	 HAL_I2C_Slave_Receive_DMA(&hi2c1, &i2c_rx_byte, 1);*/
	//ScriptEngine_Init();

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();

  /* USER CODE BEGIN RTOS_MUTEX */
	/* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* Create the semaphores(s) */
  /* creation of uartTxSemaphore */
  uartTxSemaphoreHandle = osSemaphoreNew(1, 1, &uartTxSemaphore_attributes);

  /* creation of spiTxSemaphore */
  spiTxSemaphoreHandle = osSemaphoreNew(1, 1, &spiTxSemaphore_attributes);

  /* creation of i2cTxSemaphore */
  i2cTxSemaphoreHandle = osSemaphoreNew(1, 1, &i2cTxSemaphore_attributes);

  /* creation of uart3TxSemaphore */
  uart3TxSemaphoreHandle = osSemaphoreNew(1, 1, &uart3TxSemaphore_attributes);

  /* creation of canTxSemaphore */
  canTxSemaphoreHandle = osSemaphoreNew(1, 1, &canTxSemaphore_attributes);

  /* creation of uart2TxSemaphore */
  uart2TxSemaphoreHandle = osSemaphoreNew(1, 1, &uart2TxSemaphore_attributes);

  /* creation of uart4TxSemaphore */
  uart4TxSemaphoreHandle = osSemaphoreNew(1, 1, &uart4TxSemaphore_attributes);

  /* USER CODE BEGIN RTOS_SEMAPHORES */
	/* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
	/* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of myQueue01 */
  myQueue01Handle = osMessageQueueNew (16, sizeof(uint16_t), &myQueue01_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
	/* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of BEGINTask */
  BEGINTaskHandle = osThreadNew(StartBEGINTask, NULL, &BEGINTask_attributes);

  /* creation of CANTask */
  CANTaskHandle = osThreadNew(StartCANTask, NULL, &CANTask_attributes);

  /* creation of UARTTask */
  UARTTaskHandle = osThreadNew(StartUARTTask, NULL, &UARTTask_attributes);

  /* creation of SPITask */
  SPITaskHandle = osThreadNew(StartSPITask, NULL, &SPITask_attributes);

  /* creation of I2CTask */
  I2CTaskHandle = osThreadNew(StartI2CTask, NULL, &I2CTask_attributes);

  /* creation of LEDTask */
  LEDTaskHandle = osThreadNew(StartLEDTask, NULL, &LEDTask_attributes);

  /* creation of ConfigTask */
  ConfigTaskHandle = osThreadNew(StartConfigTask, NULL, &ConfigTask_attributes);

  /* creation of COMTask */
  COMTaskHandle = osThreadNew(StartCOMTask, NULL, &COMTask_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
	/* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* Create the event(s) */
  /* creation of ConfigEvent */
  ConfigEventHandle = osEventFlagsNew(&ConfigEvent_attributes);

  /* USER CODE BEGIN RTOS_EVENTS */
	/* add events, ... */
  ScriptEngine_Init();
  InitQueues();


  HAL_FLASH_Unlock();
  __HAL_FLASH_CLEAR_FLAG(FLASH_FLAG_EOP | FLASH_FLAG_OPERR | FLASH_FLAG_WRPERR);
  HAL_FLASH_Lock();
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	while (1) {

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_LSI|RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.LSIState = RCC_LSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 180;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 2;
  RCC_OscInitStruct.PLL.PLLR = 2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Activate the Over-Drive mode
  */
  if (HAL_PWREx_EnableOverDrive() != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief CAN1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_CAN1_Init(void)
{

  /* USER CODE BEGIN CAN1_Init 0 */

  /* USER CODE END CAN1_Init 0 */

  /* USER CODE BEGIN CAN1_Init 1 */

  /* USER CODE END CAN1_Init 1 */
  hcan1.Instance = CAN1;
  hcan1.Init.Prescaler = 5;
  hcan1.Init.Mode = CAN_MODE_NORMAL;
  hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;
  hcan1.Init.TimeSeg1 = CAN_BS1_7TQ;
  hcan1.Init.TimeSeg2 = CAN_BS2_1TQ;
  hcan1.Init.TimeTriggeredMode = DISABLE;
  hcan1.Init.AutoBusOff = DISABLE;
  hcan1.Init.AutoWakeUp = DISABLE;
  hcan1.Init.AutoRetransmission = DISABLE;
  hcan1.Init.ReceiveFifoLocked = DISABLE;
  hcan1.Init.TransmitFifoPriority = ENABLE;
  if (HAL_CAN_Init(&hcan1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN CAN1_Init 2 */

  /* USER CODE END CAN1_Init 2 */

}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 400000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief IWDG Initialization Function
  * @param None
  * @retval None
  */
static void MX_IWDG_Init(void)
{

  /* USER CODE BEGIN IWDG_Init 0 */

  /* USER CODE END IWDG_Init 0 */

  /* USER CODE BEGIN IWDG_Init 1 */

  /* USER CODE END IWDG_Init 1 */
  hiwdg.Instance = IWDG;
  hiwdg.Init.Prescaler = IWDG_PRESCALER_4;
  hiwdg.Init.Reload = 999;
  if (HAL_IWDG_Init(&hiwdg) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN IWDG_Init 2 */

  /* USER CODE END IWDG_Init 2 */

}

/**
  * @brief SPI1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_SPI1_Init(void)
{

  /* USER CODE BEGIN SPI1_Init 0 */

  /* USER CODE END SPI1_Init 0 */

  /* USER CODE BEGIN SPI1_Init 1 */

  /* USER CODE END SPI1_Init 1 */
  /* SPI1 parameter configuration*/
  hspi1.Instance = SPI1;
  hspi1.Init.Mode = SPI_MODE_MASTER;
  hspi1.Init.Direction = SPI_DIRECTION_2LINES;
  hspi1.Init.DataSize = SPI_DATASIZE_8BIT;
  hspi1.Init.CLKPolarity = SPI_POLARITY_LOW;
  hspi1.Init.CLKPhase = SPI_PHASE_1EDGE;
  hspi1.Init.NSS = SPI_NSS_SOFT;
  hspi1.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
  hspi1.Init.FirstBit = SPI_FIRSTBIT_MSB;
  hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
  hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
  hspi1.Init.CRCPolynomial = 10;
  if (HAL_SPI_Init(&hspi1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN SPI1_Init 2 */

  /* USER CODE END SPI1_Init 2 */

}

/**
  * @brief TIM7 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM7_Init(void)
{

  /* USER CODE BEGIN TIM7_Init 0 */

  /* USER CODE END TIM7_Init 0 */

  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM7_Init 1 */

  /* USER CODE END TIM7_Init 1 */
  htim7.Instance = TIM7;
  htim7.Init.Prescaler = 90-1;
  htim7.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim7.Init.Period = 0xFFFF-1;
  htim7.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim7) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim7, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM7_Init 2 */

  /* USER CODE END TIM7_Init 2 */

}

/**
  * @brief UART4 Initialization Function
  * @param None
  * @retval None
  */
static void MX_UART4_Init(void)
{

  /* USER CODE BEGIN UART4_Init 0 */

  /* USER CODE END UART4_Init 0 */

  /* USER CODE BEGIN UART4_Init 1 */

  /* USER CODE END UART4_Init 1 */
  huart4.Instance = UART4;
  huart4.Init.BaudRate = 115200;
  huart4.Init.WordLength = UART_WORDLENGTH_8B;
  huart4.Init.StopBits = UART_STOPBITS_1;
  huart4.Init.Parity = UART_PARITY_NONE;
  huart4.Init.Mode = UART_MODE_TX_RX;
  huart4.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart4.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart4) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN UART4_Init 2 */

  /* USER CODE END UART4_Init 2 */

}

/**
  * @brief USART1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART1_UART_Init(void)
{

  /* USER CODE BEGIN USART1_Init 0 */

  /* USER CODE END USART1_Init 0 */

  /* USER CODE BEGIN USART1_Init 1 */

  /* USER CODE END USART1_Init 1 */
  huart1.Instance = USART1;
  huart1.Init.BaudRate = 115200;
  huart1.Init.WordLength = UART_WORDLENGTH_8B;
  huart1.Init.StopBits = UART_STOPBITS_1;
  huart1.Init.Parity = UART_PARITY_NONE;
  huart1.Init.Mode = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART1_Init 2 */
	uart_cfg = huart1.Init;
  /* USER CODE END USART1_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 115200;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief USART3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}

/**
  * Enable DMA controller clock
  */
static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA2_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  /* DMA interrupt init */
  /* DMA1_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream0_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream0_IRQn);
  /* DMA1_Stream1_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);
  /* DMA1_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream2_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream2_IRQn);
  /* DMA1_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream3_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream3_IRQn);
  /* DMA1_Stream4_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);
  /* DMA1_Stream5_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream5_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream5_IRQn);
  /* DMA1_Stream6_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream6_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream6_IRQn);
  /* DMA1_Stream7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA1_Stream7_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream7_IRQn);
  /* DMA2_Stream0_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream0_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream0_IRQn);
  /* DMA2_Stream2_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream2_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream2_IRQn);
  /* DMA2_Stream3_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream3_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream3_IRQn);
  /* DMA2_Stream7_IRQn interrupt configuration */
  HAL_NVIC_SetPriority(DMA2_Stream7_IRQn, 5, 0);
  HAL_NVIC_EnableIRQ(DMA2_Stream7_IRQn);

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */
  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3|COM_LED_Pin|ERROR_Pin|POWEER_Pin
                          |LED1_Pin|LED2_Pin|LED3_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOA, WIFI_LED_Pin|WIFI_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, GPIO_PIN_RESET);

  /*Configure GPIO pin : PC13 */
  GPIO_InitStruct.Pin = GPIO_PIN_13;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PC3 */
  GPIO_InitStruct.Pin = GPIO_PIN_3;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : PA4 */
  GPIO_InitStruct.Pin = GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : WIFI_LED_Pin WIFI_Pin */
  GPIO_InitStruct.Pin = WIFI_LED_Pin|WIFI_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pins : COM_LED_Pin ERROR_Pin POWEER_Pin LED1_Pin
                           LED2_Pin LED3_Pin */
  GPIO_InitStruct.Pin = COM_LED_Pin|ERROR_Pin|POWEER_Pin|LED1_Pin
                          |LED2_Pin|LED3_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

  /*Configure GPIO pin : LED4_Pin */
  GPIO_InitStruct.Pin = LED4_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(LED4_GPIO_Port, &GPIO_InitStruct);

  /* USER CODE BEGIN MX_GPIO_Init_2 */
  /* USER CODE END MX_GPIO_Init_2 */
}

/* USER CODE BEGIN 4 */
void print_all_task_stacks(void)
{
    const UBaseType_t max_tasks = 10;
    TaskStatus_t task_status[max_tasks];
    UBaseType_t task_count;
    uint32_t total_run_time;

    task_count = uxTaskGetSystemState(task_status, max_tasks, &total_run_time);

    char line[64];

    HAL_UART_Transmit(&huart2, (uint8_t*)"Task         FreeStackWords\r\n", 30, 200);
    HAL_UART_Transmit(&huart2, (uint8_t*)"===========================\r\n", 30, 200);

    for (UBaseType_t i = 0; i < task_count; i++) {
        snprintf(line, sizeof(line), "%-12s %5u\r\n",
                 task_status[i].pcTaskName,
                 (unsigned int)task_status[i].usStackHighWaterMark);

        HAL_UART_Transmit(&huart2, (uint8_t*)line, strlen(line), 200);
    }

    HAL_UART_Transmit(&huart2, (uint8_t*)"\r\n", 2, 200);
}
void Set_Pin_Output(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;  // <== add this
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

void Set_Pin_Input(GPIO_TypeDef *GPIOx, uint16_t GPIO_Pin)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	GPIO_InitStruct.Pin = GPIO_Pin;
	GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
	GPIO_InitStruct.Pull = GPIO_NOPULL;

	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;  // <== optional
	HAL_GPIO_Init(GPIOx, &GPIO_InitStruct);
}

void delay_us (uint16_t us)
{
__HAL_TIM_SET_COUNTER(&htim7,0);  // set the counter value a 0
while (__HAL_TIM_GET_COUNTER(&htim7) < us);  // wait for the counter to reach the us input in the parameter
}
void CAN_Init(void) {

	CAN_FilterTypeDef filter;
	filter.FilterActivation = CAN_FILTER_ENABLE;
	filter.FilterBank = 0;
	filter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
	filter.FilterIdHigh = 0;
	filter.FilterIdLow = 0;
	filter.FilterMaskIdHigh = 0;
	filter.FilterMaskIdLow = 0;
	filter.FilterMode = CAN_FILTERMODE_IDMASK;
	filter.FilterScale = CAN_FILTERSCALE_16BIT;
	filter.SlaveStartFilterBank = 27;
	HAL_CAN_ConfigFilter(&hcan1, &filter);
	HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);

	if (HAL_CAN_Start(&hcan1) != HAL_OK) {
		Error_Handler();
	}
}
void InitRoutingMatrix(void) {
	for (uint8_t from = 0; from < NUM_PROTOCOLS; from++) {
		for (uint8_t to = 0; to < NUM_PROTOCOLS; to++) {
			RoutingMatrix[from][to] = 0;
		}
	}
}
void InitQueues(void) {
    osMessageQueueAttr_t attr; // Declare a local attributes structure

    // --- Initialize protocolQueues statically ---
    for (int i = 0; i < NUM_PROTOCOLS; i++) {
        // Configure the attributes for the current protocol queue
        attr.name = "protocolQueue"; // Optional: Name for RTOS debugger views
        attr.cb_mem = &protocolQueues_cb[i]; // Point to the pre-allocated control block memory
        attr.cb_size = sizeof(protocolQueues_cb[i]); // Specify the size of the control block memory
        attr.mq_mem = protocolQueues_buf[i]; // Point to the pre-allocated message buffer memory
        attr.mq_size = sizeof(protocolQueues_buf[i]); // Specify the size of the message buffer memory

        // Create the message queue using the static attributes
        protocolQueues[i] = osMessageQueueNew(PROTOCOLS_QUEUE_SIZE, sizeof(IncomingMessage), &attr);

        if (protocolQueues[i] == NULL) {
            // Error handling: Static queue creation failed.
            Error_Handler(); // Call your system's error handler
        }
    }

    // --- Initialize luaQueueHandle statically ---
    // Configure attributes for the Lua queue
    attr.name = "luaQueue"; // Optional: Name for RTOS debugger views
    attr.cb_mem = &luaQueueHandle_cb; // Point to the pre-allocated control block memory
    attr.cb_size = sizeof(luaQueueHandle_cb); // Specify the size of the control block memory
    attr.mq_mem = luaQueueHandle_buf; // Point to the pre-allocated message buffer memory
    attr.mq_size = sizeof(luaQueueHandle_buf); // Specify the size of the message buffer memory

    // Create the Lua message queue using the static attributes
    luaQueueHandle = osMessageQueueNew(LUA_QUEUE_SIZE, sizeof(LuaMessage), &attr);

    if (luaQueueHandle == NULL) {
        Error_Handler();
    }
}
void SetRoutingRule(ProtocolType from, ProtocolType to, uint8_t value) {
	if (from == to)
		return; // Block self-forwarding
	RoutingMatrix[from][to] = value; // 0 or 1
}
void SetBridingRule(ProtocolType from, ProtocolType to, uint8_t value) {
	if (from == to)
		return; // Block self-forwarding
	RoutingMatrix[from][to] = value; // 0 or 1
	RoutingMatrix[to][from] = value;
}
ProtocolType get_protocol_from_name(const char *name) {
	for (int i = 0; i < sizeof(protocol_map) / sizeof(ProtocolLookup); i++) {
		if (strcmp(name, protocol_map[i].name) == 0) {
			return protocol_map[i].protocol;
		}
	}
	return NUM_PROTOCOLS;  // Invalid protocol
}
/*
 * UART Reconfiguration Command Format:
 * @UART SET <baudrate> <word_length> <stop_bits> <parity> <rx_size>
 *
 * - baudrate:     1200 - 4000000
 * - word_length:  8 or 9 (bits)
 * - stop_bits:    1 or 2
 * - parity:       0 = None, 1 = Even, 2 = Odd
 * - rx_size:      1 - 32 (bytes per reception)
 *
 * Example:
 *   @UART SET 115200 8 1 0 1
 */
static HAL_StatusTypeDef UART1_ApplyConfig(void) {
	HAL_StatusTypeDef st;

	// 1. Abort ongoing activity
	HAL_UART_Abort_IT(&huart1);

	// 2. DeInit
	st = HAL_UART_DeInit(&huart1);
	if (st != HAL_OK)
		return st;

	// 3. Update configuration
	huart1.Init.BaudRate = uart_baudrate;
	huart1.Init.WordLength = uart_wordlength;
	huart1.Init.StopBits = uart_stopbits;
	huart1.Init.Parity = uart_parity;
	huart1.Init.Mode = UART_MODE_TX_RX;
	huart1.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart1.Init.OverSampling = UART_OVERSAMPLING_16;

	__disable_irq();

	st = HAL_UART_Init(&huart1);
	if (st != HAL_OK)
		return st;
	__enable_irq();
	// 5. Restart reception with new size
	HAL_UART_Receive_IT(&huart1, uart1_rx_byte, UART_rx_size);

	return HAL_OK;
}
uint8_t process_uart_command(const char *body) {
	char *token;
	char *endptr;
	char temp[MAX_CMD_LEN];
	strncpy(temp, body, MAX_CMD_LEN - 1);
	temp[MAX_CMD_LEN - 1] = '\0';

	uint32_t args[5];
	uint8_t arg_count = 0;

	token = strtok(temp, " ");
	while (token != NULL && arg_count < 6) {
		args[arg_count++] = strtoul(token, &endptr, 10);
		if (*endptr != '\0') {
			return 0;  // Non-numeric
		}
		token = strtok(NULL, " ");
	}

	if (arg_count != 5)
		return 0;

	uint32_t new_baud = args[0];
	uint32_t word_length = args[1];
	uint32_t stop_bits = args[2];
	uint32_t parity = args[3];
	uint32_t rx_size = args[4];


	// Validate
	if (new_baud < 1200 || new_baud > 4000000)
		return 0;

	if (word_length != 8 && word_length != 9)
		return 0;

	if (stop_bits != 1 && stop_bits != 2)
		return 0;

	if (parity > 2)
		return 0;

	if (rx_size == 0 || rx_size >= 32)
		return 0;

	// Apply config
	uart_baudrate = new_baud;
	uart_wordlength =
			(word_length == 8) ? UART_WORDLENGTH_8B : UART_WORDLENGTH_9B;
	uart_stopbits = (stop_bits == 1) ? UART_STOPBITS_1 : UART_STOPBITS_2;
	uart_parity = (parity == 0) ? UART_PARITY_NONE :
					(parity == 1) ? UART_PARITY_EVEN : UART_PARITY_ODD;
	UART_rx_size = rx_size;

	// Apply to hardware
	if (UART1_ApplyConfig() != HAL_OK)
		return 0;

	return 1;
}
/*
 * SPI Reconfiguration Command Format:
 * @SPI SET <mode> <prescaler> <cpol> <cpha> <data_size> <bit_order> <rx_size>
 *
 * - mode:         0 = Master (Transmit),
 *                 1 = Master (TransmitReceive),
 *                 2 = Slave
 * - prescaler:    2, 4, 8, 16, 32, 64, 128, 256
 * - cpol:         0 = Low, 1 = High
 * - cpha:         0 = First edge, 1 = Second edge
 * - data_size:    4 - 16 bits
 * - bit_order:    0 = MSB first, 1 = LSB first
 * - rx_size:      1 - 32
 *
 * Example:
 *   @SPI SET 0 16 0 0 8 0 4
 */

static HAL_StatusTypeDef SPI1_ApplyConfig(void) {
	HAL_StatusTypeDef status;

	HAL_SPI_DeInit(&hspi1);

	hspi1.Init.Mode = (SPI_mode == 2) ? SPI_MODE_SLAVE : SPI_MODE_MASTER;
	hspi1.Init.Direction = SPI_DIRECTION_2LINES;
	hspi1.Init.DataSize =
			(SPI_data_size <= 8) ? SPI_DATASIZE_8BIT : SPI_DATASIZE_16BIT;
	hspi1.Init.CLKPolarity =
			(SPI_cpol == 0) ? SPI_POLARITY_LOW : SPI_POLARITY_HIGH;
	hspi1.Init.CLKPhase = (SPI_cpha == 0) ? SPI_PHASE_1EDGE : SPI_PHASE_2EDGE;
	hspi1.Init.NSS = SPI_NSS_SOFT;
	hspi1.Init.BaudRatePrescaler =
			(SPI_prescaler == 2) ? SPI_BAUDRATEPRESCALER_2 :
			(SPI_prescaler == 4) ? SPI_BAUDRATEPRESCALER_4 :
			(SPI_prescaler == 8) ? SPI_BAUDRATEPRESCALER_8 :
			(SPI_prescaler == 16) ? SPI_BAUDRATEPRESCALER_16 :
			(SPI_prescaler == 32) ? SPI_BAUDRATEPRESCALER_32 :
			(SPI_prescaler == 64) ? SPI_BAUDRATEPRESCALER_64 :
			(SPI_prescaler == 128) ?
			SPI_BAUDRATEPRESCALER_128 :
										SPI_BAUDRATEPRESCALER_256;
	hspi1.Init.FirstBit =
			(SPI_bit_order == 0) ? SPI_FIRSTBIT_MSB : SPI_FIRSTBIT_LSB;
	hspi1.Init.TIMode = SPI_TIMODE_DISABLE;
	hspi1.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspi1.Init.CRCPolynomial = 7;

	__disable_irq();
	status = HAL_SPI_Init(&hspi1);
	if (status != HAL_OK)
		return status;

	if (SPI_mode == 2) {
		return HAL_SPI_Receive_DMA(&hspi1, spi_rx_byte, SPI_rx_size);
	}
	__enable_irq();

	return HAL_OK;
}

uint8_t process_spi_command(const char *body) {
	char *token, *endptr;
	char temp[MAX_CMD_LEN];
	strncpy(temp, body, MAX_CMD_LEN - 1);
	temp[MAX_CMD_LEN - 1] = '\0';

	uint32_t args[7];
	uint8_t arg_count = 0;

	token = strtok(temp, " ");
	while (token != NULL && arg_count < 9) {
		args[arg_count++] = strtoul(token, &endptr, 0);
		if (*endptr != '\0')
			return 0;
		token = strtok(NULL, " ");
	}

	if (arg_count != 7)
		return 0;

	uint32_t mode = args[0];
	uint32_t prescaler = args[1];
	uint32_t cpol = args[2];
	uint32_t cpha = args[3];
	uint32_t data_size = args[4];
	uint32_t bit_order = args[5];
	uint32_t rx_size = args[6];

	// Validation
	if (mode > 2)
		return 0;
	if (!(prescaler == 2 || prescaler == 4 || prescaler == 8 || prescaler == 16
			|| prescaler == 32 || prescaler == 64 || prescaler == 128
			|| prescaler == 256))
		return 0;
	if (cpol > 1 || cpha > 1 || bit_order > 1)
		return 0;
	if (data_size < 4 || data_size > 16)
		return 0;
	if ( rx_size == 0 || rx_size > 33)
		return 0;

	// Store
	SPI_mode = mode;
	SPI_prescaler = prescaler;
	SPI_cpol = cpol;
	SPI_cpha = cpha;
	SPI_data_size = data_size;
	SPI_bit_order = bit_order;
	SPI_rx_size = rx_size;

	if (SPI1_ApplyConfig() != HAL_OK)
		return 0;

	return 1;
}
/*
 * CAN Reconfiguration Command Format:
 * @CAN SET <prescaler> <time_seg1> <time_seg2> <msg_id> <filter_id> <filter_mask>
 *
 * - prescaler:    1 - 1024 (affects bitrate)
 * - time_seg1:    1 - 15
 * - time_seg2:    1 - 8
 * - msg_id:       0x000 - 0x7FF (11-bit CAN ID)
 * - filter_id:    0x000 - 0x7FF
 * - filter_mask:  0x000 - 0x7FF
 *
 * Example:
 *   @CAN SET 10 13 2 0x123 0x000 0x000
 */

static HAL_StatusTypeDef CAN1_ApplyConfig(void) {
	HAL_StatusTypeDef status;

	HAL_CAN_DeInit(&hcan1);

	hcan1.Init.Prescaler = CAN_prescaler;
	hcan1.Init.Mode = CAN_MODE_NORMAL;
	hcan1.Init.SyncJumpWidth = CAN_SJW_1TQ;

	// Use macros directly for segment timing
	switch (CAN_time_seg1) {
	case 1:
		hcan1.Init.TimeSeg1 = CAN_BS1_1TQ;
		break;
	case 2:
		hcan1.Init.TimeSeg1 = CAN_BS1_2TQ;
		break;
	case 3:
		hcan1.Init.TimeSeg1 = CAN_BS1_3TQ;
		break;
	case 4:
		hcan1.Init.TimeSeg1 = CAN_BS1_4TQ;
		break;
	case 5:
		hcan1.Init.TimeSeg1 = CAN_BS1_5TQ;
		break;
	case 6:
		hcan1.Init.TimeSeg1 = CAN_BS1_6TQ;
		break;
	case 7:
		hcan1.Init.TimeSeg1 = CAN_BS1_7TQ;
		break;
	case 8:
		hcan1.Init.TimeSeg1 = CAN_BS1_8TQ;
		break;
	case 9:
		hcan1.Init.TimeSeg1 = CAN_BS1_9TQ;
		break;
	case 10:
		hcan1.Init.TimeSeg1 = CAN_BS1_10TQ;
		break;
	case 11:
		hcan1.Init.TimeSeg1 = CAN_BS1_11TQ;
		break;
	case 12:
		hcan1.Init.TimeSeg1 = CAN_BS1_12TQ;
		break;
	case 13:
		hcan1.Init.TimeSeg1 = CAN_BS1_13TQ;
		break;
	case 14:
		hcan1.Init.TimeSeg1 = CAN_BS1_14TQ;
		break;
	case 15:
		hcan1.Init.TimeSeg1 = CAN_BS1_15TQ;
		break;
	case 16:
		hcan1.Init.TimeSeg1 = CAN_BS1_16TQ;
		break;
	default:
		return HAL_ERROR;
	}

	switch (CAN_time_seg2) {
	case 1:
		hcan1.Init.TimeSeg2 = CAN_BS2_1TQ;
		break;
	case 2:
		hcan1.Init.TimeSeg2 = CAN_BS2_2TQ;
		break;
	case 3:
		hcan1.Init.TimeSeg2 = CAN_BS2_3TQ;
		break;
	case 4:
		hcan1.Init.TimeSeg2 = CAN_BS2_4TQ;
		break;
	case 5:
		hcan1.Init.TimeSeg2 = CAN_BS2_5TQ;
		break;
	case 6:
		hcan1.Init.TimeSeg2 = CAN_BS2_6TQ;
		break;
	case 7:
		hcan1.Init.TimeSeg2 = CAN_BS2_7TQ;
		break;
	case 8:
		hcan1.Init.TimeSeg2 = CAN_BS2_8TQ;
		break;
	default:
		return HAL_ERROR;
	}

	hcan1.Init.TimeTriggeredMode = DISABLE;
	hcan1.Init.AutoBusOff = DISABLE;
	hcan1.Init.AutoWakeUp = DISABLE;
	hcan1.Init.AutoRetransmission = DISABLE;
	hcan1.Init.ReceiveFifoLocked = DISABLE;
	hcan1.Init.TransmitFifoPriority = DISABLE;

	__disable_irq();
	status = HAL_CAN_Init(&hcan1);
	__enable_irq();
	if (status != HAL_OK)
		return status;

	// Filter config
	CAN_FilterTypeDef filter;
	filter.FilterBank = 0;
	filter.FilterMode = CAN_FILTERMODE_IDMASK;
	filter.FilterScale = CAN_FILTERSCALE_32BIT;
	filter.FilterIdHigh = (CAN_filter_id << 5);
	filter.FilterMaskIdHigh = (CAN_filter_mask << 5);
	filter.FilterIdLow = 0;
	filter.FilterMaskIdLow = 0;
	filter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
	filter.FilterActivation = ENABLE;
	filter.SlaveStartFilterBank = 14;

	__disable_irq();
	status = HAL_CAN_ConfigFilter(&hcan1, &filter);
	__enable_irq();

	return status;
}

uint8_t process_can_command(const char *body) {
	char *token, *endptr;
	char temp[MAX_CMD_LEN];
	strncpy(temp, body, MAX_CMD_LEN - 1);
	temp[MAX_CMD_LEN - 1] = '\0';

	uint32_t args[6];
	uint8_t arg_count = 0;

	token = strtok(temp, " ");
	while (token != NULL && arg_count < 7) {
		args[arg_count++] = strtoul(token, &endptr, 0);
		if (*endptr != '\0')
			return 0;
		token = strtok(NULL, " ");
	}

	if (arg_count != 6)
		return 0;

	uint32_t prescaler = args[0];
	uint32_t seg1 = args[1];
	uint32_t seg2 = args[2];
	uint32_t msg_id = args[3] & 0x7FF;
	uint32_t filter_id = args[4] & 0x7FF;
	uint32_t filter_mask = args[5] & 0x7FF;


	// Validation
	if (prescaler < 1 || prescaler > 1024)
		return 0;
	if (seg1 < 1 || seg1 > 15)
		return 0;
	if (seg2 < 1 || seg2 > 8)
		return 0;


	// Apply
	CAN_prescaler = prescaler;
	CAN_time_seg1 = seg1;
	CAN_time_seg2 = seg2;
	CAN_msg_id = msg_id;
	CAN_filter_id = filter_id;
	CAN_filter_mask = filter_mask;


	if (CAN1_ApplyConfig() != HAL_OK)
		return 0;

	return 1;
}
/*
 * I2C Reconfiguration Command Format:
 * @I2C SET <speed> <mode> <own_addr> <slave_addr> <mem_addr> <rx_size>
 *
 * - speed:        10000 - 400000 (Hz)
 * - mode:         0 = Master TX, 1 = Master RX, 2 = Memory Read, 3 = Slave
 * - own_addr:     7-bit address (0x00 - 0x7F)
 * - slave_addr:   7-bit address (0x00 - 0x7F)
 * - mem_addr:     8-bit memory address (for mode 2)
 * - rx_size:      1 - 32
 *
 * Example:
 *   @I2C SET 100000 1 0x01 0x10 0x00 4
 */

static HAL_StatusTypeDef I2C1_ApplyConfig(void) {
	HAL_StatusTypeDef status;

	HAL_I2C_DeInit(&hi2c1);

	hi2c1.Init.ClockSpeed = I2C_speed;
	hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
	hi2c1.Init.OwnAddress1 = I2C_own_addr << 1; // STM expects 8-bit
	hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	hi2c1.Init.OwnAddress2 = 0;
	hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;

	if ((status = HAL_I2C_Init(&hi2c1)) != HAL_OK)
		return status;

	// Restart according to mode
	switch (I2C_mode) {
	case 0: // Master Transmit — no preload
		break;

	case 1: // Master Receive
		HAL_I2C_Master_Receive_DMA(&hi2c1, I2C_slave_addr , i2c_rx_byte,
				I2C_read_size);
		break;

	case 2: // Master Memory Read
		HAL_I2C_Mem_Read_DMA(&hi2c1, I2C_slave_addr , I2C_mem_addr,
		I2C_MEMADD_SIZE_8BIT, i2c_rx_byte, I2C_read_size);
		break;

	case 3: // Slave
		HAL_I2C_Slave_Receive_DMA(&hi2c1, i2c_rx_byte, I2C_read_size);
		break;
	}

	return HAL_OK;
}


uint8_t process_i2c_command(const char *body) {
	char *token, *endptr;
	char temp[MAX_CMD_LEN];
	strncpy(temp, body, MAX_CMD_LEN - 1);
	temp[MAX_CMD_LEN - 1] = '\0';

	uint32_t args[6];
	uint8_t arg_count = 0;

	token = strtok(temp, " ");
	while (token != NULL && arg_count < 7) {
		args[arg_count++] = strtoul(token, &endptr, 0);
		if (*endptr != '\0')
			return 0;
		token = strtok(NULL, " ");
	}

	if (arg_count != 6)
		return 0;

	// Extract and validate
	uint32_t speed = args[0];
	uint32_t mode = args[1];
	uint32_t own_addr = args[2] & 0x7F;  // 7-bit
	uint32_t slave_addr = args[3] & 0x7F;  // 7-bit
	uint32_t mem_addr = args[4];
	uint32_t rx_size = args[5];


	if (speed < 10000 || speed > 400000)
		return 0;

	if (mode > 3)
		return 0;

	if (rx_size == 0 || rx_size > 32)
		return 0;

	// Apply all validated values
	I2C_speed = speed;
	I2C_mode = mode;
	I2C_own_addr = own_addr << 1;
	I2C_slave_addr = slave_addr << 1;
	I2C_mem_addr = mem_addr;
	I2C_read_size = rx_size;


	// Reapply hardware config
	if (I2C1_ApplyConfig() != HAL_OK)
		return 0;

	return 1;
}

void ClearAllQueuesAndBuffers(void) {
	IncomingMessage dummy;
	osStatus_t status;

	// Clear all message queues
	for (int i = 0; i < NUM_PROTOCOLS; i++) {
		while ((status = osMessageQueueGet(protocolQueues[i], &dummy, NULL, 0))
				== osOK) {
			// Discard messages
		}
	}

	// Clear UART buffers
	memset(uart1_rx_byte, 0, sizeof(uart1_rx_byte));
	memset(uart2_rx_buffer, 0, sizeof(uart2_rx_buffer));
	uart2_rx_len = 0;
	collecting_cmd = 0;
	memset(uart_tx_buffer, 0, sizeof(uart_tx_buffer));
	uart_buffer_length = 0;

	// Clear SPI buffers
	memset(spi_txrx_buffer, 0, sizeof(spi_txrx_buffer));
	spi_txrx_len = 0;
	memset(spi_rx_byte, 0, sizeof(spi_rx_byte));
	memset(spi_tx_buffer, 0, sizeof(spi_tx_buffer));
	spi_buffer_length = 0;

	// Clear I2C buffers
	memset(i2c_rx_byte, 0, sizeof(i2c_rx_byte));
	memset(i2c_tx_buffer, 0, sizeof(i2c_tx_buffer));
	i2c_buffer_len = 0;

	// Clear CAN buffers
	memset(can_tx_buffer, 0, sizeof(can_tx_buffer));
	can_buffer_length = 0;
}

void process_command(char *cmd) {

	// 1. Handle forwarding commands
	if (strcmp(cmd, "ROUTE RESET") == 0) {
		InitRoutingMatrix();
		HAL_UART_Transmit(&huart2, (uint8_t*) "ROUTE RESET\n", 16, 200);
		return;
	} else if (strcmp(cmd, "ROUTE ALL") == 0) {
		for (uint8_t i = 0; i < NUM_PROTOCOLS; i++) {
			for (uint8_t j = 0; j < NUM_PROTOCOLS; j++) {
				SetRoutingRule(i, j, (i != j) ? 1 : 0);
			}
		}
		HAL_UART_Transmit(&huart2, (uint8_t*) "ROUTE ALL\n", 15, 200);
		return;
	} // New ROUTE format: "ROUTE <PROTO> <bit0> <bit1> ... <bitN>"
	else if (strncasecmp(cmd, "ROUTE ", 6) == 0) {
		char proto_name[8];
		int values[NUM_PROTOCOLS];
		int matched = sscanf(cmd, "ROUTE %7s %d %d %d %d %d", proto_name,
				&values[0], &values[1], &values[2], &values[3], &values[4]);

		if (matched == (1 + NUM_PROTOCOLS)) {
			ProtocolType from = get_protocol_from_name(proto_name);
			if (from >= NUM_PROTOCOLS) {
				HAL_UART_Transmit(&huart2, (uint8_t*) "ROUTE ERR\n", 10, 200);
				return;
			}

			for (int to = 0; to < NUM_PROTOCOLS; ++to) {
				if (from != to) {  // prevent self-routing
					RoutingMatrix[from][to] = (values[to] != 0);
				}
			}

			HAL_UART_Transmit(&huart2, (uint8_t*) "ROUTE OK\n", 9, 200);
			return;
		}
	}

	// 2. Handle UART configuration
	else if (strncasecmp(cmd, "UART SET ", 9) == 0) {
		if (process_uart_command(cmd + 9)) {
			HAL_UART_Transmit(&huart2, (uint8_t*) "UART OK\n", 8, 200);
			HAL_UART_Transmit(&huart3, (uint8_t*) "UART OK\n", 8, 200);
			HAL_UART_Transmit(&huart4, (uint8_t*) "UART OK\n", 8, 200);
		} else {
			HAL_UART_Transmit(&huart2, (uint8_t*) "UART ERR\n", 9, 200);
			HAL_UART_Transmit(&huart3, (uint8_t*) "UART ERR\n", 9, 200);
			HAL_UART_Transmit(&huart4, (uint8_t*) "UART ERR\n", 9, 200);
		}
	}

	// 3. Handle SPI configuration
	else if (strncasecmp(cmd, "SPI SET ", 8) == 0) {
		if (process_spi_command(cmd + 8)) {
			HAL_UART_Transmit(&huart2, (uint8_t*) "SPI OK\n", 7, 200);
			HAL_UART_Transmit(&huart3, (uint8_t*) "SPI OK\n", 7, 200);
			HAL_UART_Transmit(&huart4, (uint8_t*) "SPI OK\n", 7, 200);
		} else {
			HAL_UART_Transmit(&huart2, (uint8_t*) "SPI ERR\n", 8, 200);
			HAL_UART_Transmit(&huart3, (uint8_t*) "SPI ERR\n", 8, 200);
			HAL_UART_Transmit(&huart4, (uint8_t*) "SPI ERR\n", 8, 200);
		}
		return;
	} else if (strncasecmp(cmd, "CAN SET ", 8) == 0) {
		if (process_can_command(cmd + 8)) {
			HAL_UART_Transmit(&huart2, (uint8_t*) "CAN OK\n", 7, 200);
			HAL_UART_Transmit(&huart3, (uint8_t*) "CAN OK\n", 7, 200);
			HAL_UART_Transmit(&huart4, (uint8_t*) "CAN OK\n", 7, 200);
		} else {
			HAL_UART_Transmit(&huart2, (uint8_t*) "CAN ERR\n", 8, 200);
			HAL_UART_Transmit(&huart3, (uint8_t*) "CAN ERR\n", 8, 200);
			HAL_UART_Transmit(&huart4, (uint8_t*) "CAN ERR\n", 8, 200);
		}
		return;
	} else if (strncasecmp(cmd, "I2C SET ", 8) == 0) {
		if (process_i2c_command(cmd + 8)) {
			HAL_UART_Transmit(&huart2, (uint8_t*) "I2C OK\n", 7, 200);
			HAL_UART_Transmit(&huart3, (uint8_t*) "I2C OK\n", 7, 200);
			HAL_UART_Transmit(&huart4, (uint8_t*) "I2C OK\n", 7, 200);
		} else {
			HAL_UART_Transmit(&huart2, (uint8_t*) "I2C ERR\n", 8, 200);
			HAL_UART_Transmit(&huart3, (uint8_t*) "I2C ERR\n", 8, 200);
			HAL_UART_Transmit(&huart4, (uint8_t*) "I2C ERR\n", 8, 200);
		}
		return;
	} else if (strcasecmp(cmd, "FLUSH") == 0) {
		ClearAllQueuesAndBuffers();
		HAL_UART_Transmit(&huart2, (uint8_t*) "FLUSHED\n", 8, 200);
		HAL_UART_Transmit(&huart3, (uint8_t*) "FLUSHED\n", 8, 200);
		HAL_UART_Transmit(&huart4, (uint8_t*) "FLUSHED\n", 8, 200);
		return;
	} else if (strcasecmp(cmd, "STOP") == 0) {
        ScriptEngine_Stop();
        const char *msg = "Script stopped\n";
        HAL_UART_Transmit(&huart2, (uint8_t*)msg, strlen(msg), 200);
        HAL_UART_Transmit(&huart3, (uint8_t*)msg, strlen(msg), 200);
        HAL_UART_Transmit(&huart4, (uint8_t*)msg, strlen(msg), 200);
    }else if (strcasecmp(cmd, "HELP") == 0) {
		const char *help =
			"=============================== ROUTING COMMANDS ==============================\n"
			"@ROUTE RESET\n"
			"    - Disable all routing between protocols (clears routing matrix).\n"
			"@ROUTE ALL\n"
			"    - Enable routing between all protocols except self-routing.\n"
			"@ROUTE <FROM> TO <TO>\n"
			"    - Enable routing from one protocol to another.\n"
			"      Example: ROUTE UART TO CAN\n"
			"@ROUTE <PROTO> <b0> <b1> <b2> <b3> <b4>\n"
			"    - Set all routing outputs from one protocol in a single command.\n"
			"    - Each <bN> is 0 or 1: disables/enables routing to [UART SPI I2C CAN COM]\n"
			"      Example: ROUTE UART 0 1 0 1 0 (to SPI and CAN only)\n"
			"\n"
			"============================ PROTOCOL CONFIGURATION ==========================\n"
			"@UART SET <baud> <wordlen> <stopbits> <parity> <rx_size>\n"
			"    - baud:     1200–4000000\n"
			"    - wordlen:  8 or 9\n"
			"    - stopbits: 1 or 2\n"
			"    - parity:   0=None, 1=Even, 2=Odd\n"
			"    - rx_size:  1–32 bytes\n"
			"    - Example:  UART SET 9600 8 1 0 4\n"
			"\n"
			"@SPI SET <mode> <prescaler> <cpol> <cpha> <bits> <order> <rx>\n"
			"    - mode:     0=Master (Transmit), 1=Master (TransmitReceive), 2=Slave\n"
			"    - prescaler: 2,4,8,16,...256\n"
			"    - cpol/cpha: 0 or 1\n"
			"    - bits:     4–16\n"
			"    - order:    0=MSB first, 1=LSB first\n"
			"    - rx:       1–32 bytes\n"
			"    - Example:  SPI SET 1 16 0 0 8 0 8\n"
			"\n"
			"@I2C SET <speed> <mode> <own> <slave> <mem> <rx>\n"
			"    - speed:    10000–400000 Hz\n"
			"    - mode:     0=Master TX, 1=Master RX, 2=Memory Read, 3=Slave\n"
			"    - own:      Own address (0–127)\n"
			"    - slave:    Slave address (0–127)\n"
			"    - mem:      Memory address (for mode 2)\n"
			"    - rx:       bytes (1–32)\n"
			"    - Example:  I2C SET 100000 1 0x01 0x10 0x00 4\n"
			"\n"
			"@CAN SET <pre> <seg1> <seg2> <id> <filt> <mask>\n"
			"    - pre:      Prescaler (1–1024)\n"
			"    - seg1:     1–15 time quanta\n"
			"    - seg2:     1–8 time quanta\n"
			"    - id:       11-bit CAN ID\n"
			"    - filt:     11-bit filter ID\n"
			"    - mask:     11-bit mask\n"
			"    - Example:  CAN SET 16 13 2 0x123 0x000 0x000\n"
			"\n"
			"=============================== SYSTEM COMMANDS ============================\n"
			"@FLUSH\n"
			"    - Immediately clears all protocol queues and TX/RX buffers.\n"
			"    - Safe to call anytime; does not reinit hardware.\n"
			"\n"
			"@HELP\n"
			"    - Show this help menu.\n";

		HAL_UART_Transmit(&huart2, (uint8_t*) help, strlen(help), 200);
		return;
	}

	else {
		const char *msg = "UNKNOWN COMMAND\n";
		HAL_UART_Transmit(&huart2, (uint8_t*) msg, strlen(msg), 200);
		HAL_UART_Transmit(&huart3, (uint8_t*) msg, strlen(msg), 200);
		HAL_UART_Transmit(&huart4, (uint8_t*) msg, strlen(msg), 200);
		return;
	}

}
void SPI_RESET() {
	HAL_SPI_Abort(&hspi1);

	if (HAL_SPI_DeInit(&hspi1) != HAL_OK) {
		Error_Handler();

	}
	if (HAL_SPI_Init(&hspi1) != HAL_OK) {
		Error_Handler();

	}

	if (hspi1.Init.Mode == SPI_MODE_SLAVE) {
		HAL_SPI_Receive_DMA(&hspi1, spi_rx_byte, SPI_rx_size);
	}
}
void I2C_RESET() {

	HAL_I2C_DeInit(&hi2c1);

	if (HAL_I2C_Init(&hi2c1) != HAL_OK) {
		Error_Handler();
	}
	if (I2C_mode == 2) { // Slave mode
		HAL_I2C_Slave_Receive_DMA(&hi2c1, i2c_rx_byte, I2C_read_size);
	}
}
void CAN_RESET() {
	HAL_CAN_Stop(&hcan1);

	if (HAL_CAN_DeInit(&hcan1) != HAL_OK) {
		Error_Handler();
	}

	if (HAL_CAN_Init(&hcan1) != HAL_OK) {
		Error_Handler();
	}

	HAL_CAN_Start(&hcan1);
	HAL_CAN_ActivateNotification(&hcan1, CAN_IT_RX_FIFO0_MSG_PENDING);
	memset(can_tx_buffer, 0, sizeof(can_tx_buffer)); // Clear buffer
	can_buffer_length = 0; // Reset length

}
void UART_RESET() {
	HAL_UART_Abort_IT(&huart1);

	if (HAL_UART_DeInit(&huart1) != HAL_OK) {
		Error_Handler();
	}
	if (HAL_UART_Init(&huart1) != HAL_OK) {
		Error_Handler();
	}
	HAL_UART_Receive_IT(&huart1, uart1_rx_byte, UART_rx_size);
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_StartBEGINTask */
/**
 * @brief  Function implementing the BEGINTask thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartBEGINTask */
void StartBEGINTask(void *argument)
{
  /* USER CODE BEGIN 5 */
	__disable_irq();
	//HAL_GPIO_WritePin(WIFI_GPIO_Port, WIFI_Pin, GPIO_PIN_SET);
	HAL_UART_Abort_IT(&huart4);
	HAL_GPIO_WritePin(WIFI_GPIO_Port, WIFI_Pin, GPIO_PIN_SET);
	HAL_GPIO_TogglePin(GPIOC,
	COM_LED_Pin | LED1_Pin | LED2_Pin | LED3_Pin | POWEER_Pin | ERROR_Pin);
	HAL_GPIO_TogglePin(LED4_GPIO_Port, LED4_Pin);
	if (SPI_mode == 1) {
		InitRoutingMatrix();
		RoutingMatrix[UART][SPI] = 1;
		RoutingMatrix[SPI][CAN] = 1;
		RoutingMatrix[SPI][I2C] = 1;
		RoutingMatrix[SPI][COM] = 1;
	} else {
		for (int i = 0; i < NUM_PROTOCOLS; i++) {
			for (int j = 0; j < NUM_PROTOCOLS - 1; j++) {
				if (i != j)
					RoutingMatrix[i][j] = 1;
			}
		}
	}

	for (volatile uint32_t i = 0; i < 5000000; i++)
		;

	HAL_GPIO_TogglePin(GPIOC,
	COM_LED_Pin | LED1_Pin | LED2_Pin | LED3_Pin | POWEER_Pin | ERROR_Pin);
	HAL_GPIO_TogglePin(LED4_GPIO_Port, LED4_Pin);

	if (HAL_UART_Init(&huart4) != HAL_OK) {
		Error_Handler();
	}

	HAL_UART_Receive_IT(&huart1, uart1_rx_byte, UART_rx_size);
	HAL_UART_Receive_IT(&huart2, &uart2_rx_byte, 1);
	HAL_UART_Receive_IT(&huart3, &uart2_rx_byte, 1);
	HAL_UART_Receive_DMA(&huart4, &uart2_rx_byte, 1);
	HAL_GPIO_WritePin(WIFI_LED_GPIO_Port, WIFI_LED_Pin, GPIO_PIN_SET);

	osSemaphoreRelease(uartTxSemaphoreHandle);
	osSemaphoreRelease(uart2TxSemaphoreHandle);
	osSemaphoreRelease(uart3TxSemaphoreHandle);
	osSemaphoreRelease(uart4TxSemaphoreHandle);
	osSemaphoreRelease(spiTxSemaphoreHandle);
	osSemaphoreRelease(i2cTxSemaphoreHandle);

	__enable_irq();
	//MX_IWDG_Init();

	osThreadExit();

  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_StartCANTask */
/**
 * @brief Function implementing the CANTask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartCANTask */
void StartCANTask(void *argument)
{
  /* USER CODE BEGIN StartCANTask */
	IncomingMessage msg;
	static uint8_t error_count = 0;

	/* Infinite loop */
	for (;;) {
	    if (osMessageQueueGet(protocolQueues[CAN], &msg, NULL, osWaitForever) == osOK) {
	      uint8_t offset = 0;
	      uint8_t total_len = msg.len;

	      while (offset < total_len) {
	        uint8_t chunk_len = (total_len - offset) > 8 ? 8 : (total_len - offset);

	        CAN_TxHeaderTypeDef txh = {
	          .DLC = chunk_len,
	          .StdId = CAN_msg_id,  // Use the same ID for all chunks
	          .ExtId = 0,
	          .IDE = CAN_ID_STD,
	          .RTR = CAN_RTR_DATA,
	          .TransmitGlobalTime = DISABLE
	        };

	        uint32_t txMailbox;
	        HAL_StatusTypeDef status = HAL_CAN_AddTxMessage(&hcan1, &txh, &msg.data[offset], &txMailbox);

//	        if (status != HAL_OK) {
//	          osDelay(1);
//	          status = HAL_CAN_AddTxMessage(&hcan1, &txh, &msg.data[offset], &txMailbox);
//	        }

	        if (status == HAL_OK) {
	          error_count = 0;
	          offset += chunk_len;
	        } else {
	          if (++error_count > 3) {
	            CAN_RESET();
	            error_count = 0;
	            break; // Abort transmission on CAN reset
	          }
	        }

	        HAL_GPIO_TogglePin(GPIOC, LED2_Pin);
	      }

	}}
  /* USER CODE END StartCANTask */
}

/* USER CODE BEGIN Header_StartUARTTask */
/**
 * @brief Function implementing the UARTTask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartUARTTask */
void StartUARTTask(void *argument)
{
  /* USER CODE BEGIN StartUARTTask */
	IncomingMessage msg;
	static uint8_t error_count = 0;

	/* Infinite loop */
	for (;;) {
		if (osSemaphoreAcquire(uartTxSemaphoreHandle, osWaitForever) == osOK) {
			if (osMessageQueueGet(protocolQueues[UART], &msg, NULL,
			osWaitForever) == osOK) {

				if (HAL_UART_Transmit_IT(&huart1, msg.data, msg.len)
						!= HAL_OK) {


						osSemaphoreRelease(uartTxSemaphoreHandle);
						if (++error_count > 3) {
							UART_RESET();
							error_count = 0;


					}
				} else {
					error_count = 0; // ✅ Reset counter after a successful transmission
					HAL_GPIO_TogglePin(LED1_GPIO_Port, LED1_Pin);
					continue;
				}
			}
		}
	}
  /* USER CODE END StartUARTTask */
}

/* USER CODE BEGIN Header_StartSPITask */
/**
 * @brief Function implementing the SPITask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartSPITask */
void StartSPITask(void *argument)
{
  /* USER CODE BEGIN StartSPITask */

	IncomingMessage msg;
	static uint8_t error_count = 0;

	/* Infinite loop */
	for (;;) {
		if (osSemaphoreAcquire(spiTxSemaphoreHandle, osWaitForever) == osOK) {
			if (osMessageQueueGet(protocolQueues[SPI], &msg, NULL,
			osWaitForever) == osOK) {

				if (SPI_mode == 1) {
					spi_txrx_len = msg.len;
					if (HAL_SPI_TransmitReceive_DMA(&hspi1, msg.data,
							spi_txrx_buffer, msg.len) != HAL_OK) {

						osSemaphoreRelease(spiTxSemaphoreHandle);

						if (++error_count > 3) {
							SPI_RESET();
							error_count = 0;
							continue;

						}
					} else {
						error_count = 0; // ✅ Reset counter after a successful transmission
						HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin); // Activity LED
						continue;
					}

				} else {

					if (HAL_SPI_Transmit_DMA(&hspi1, msg.data, msg.len)
							!= HAL_OK) {

						osSemaphoreRelease(spiTxSemaphoreHandle);

						if (++error_count > 3) {
							SPI_RESET();
							error_count = 0;
							continue;

						}

					} else {
						error_count = 0; // ✅ Reset counter after a successful transmission
						HAL_GPIO_TogglePin(LED3_GPIO_Port, LED3_Pin); // Activity LED
						continue;
					}

				}

		}
	}
}

  /* USER CODE END StartSPITask */
}

/* USER CODE BEGIN Header_StartI2CTask */
/**
 * @brief Function implementing the I2CTask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartI2CTask */
void StartI2CTask(void *argument)
{
  /* USER CODE BEGIN StartI2CTask */
IncomingMessage msg;
static uint8_t error_count = 0;
osDelay(10);

/* Infinite loop */
for (;;) {
	if (osSemaphoreAcquire(i2cTxSemaphoreHandle, osWaitForever) == osOK) {
		if (osMessageQueueGet(protocolQueues[I2C], &msg, NULL,
		osWaitForever) == osOK) {

			// Ignore slave/receive modes (only handle Master TX with buffering)
			if (I2C_mode == 0) {
				// Check if incoming data fits

				if (HAL_I2C_Master_Transmit_DMA(&hi2c1, I2C_slave_addr,msg.data, msg.len)
						!= HAL_OK) {

					osSemaphoreRelease(i2cTxSemaphoreHandle);

					if (++error_count > 3) {
						I2C_RESET();
						error_count = 0;
						continue;
					}

				} else {
					//osSemaphoreRelease(i2cTxSemaphoreHandle);
					error_count = 0; // ✅ Reset counter after a successful transmission
					HAL_GPIO_TogglePin(LED4_GPIO_Port, LED4_Pin);
					continue;
				}
			}

			// Keep original modes
			else if (I2C_mode == 1) {
				if (HAL_I2C_Master_Receive_DMA(&hi2c1, I2C_slave_addr,
						i2c_rx_byte, I2C_read_size) != HAL_OK) {

					osSemaphoreRelease(i2cTxSemaphoreHandle);
					if (++error_count > 3) {
						I2C_RESET();
						error_count = 0;
						continue;
					}

				} else {
					error_count = 0;
					HAL_GPIO_TogglePin(LED4_GPIO_Port, LED4_Pin);
					continue;
				}
			}
			else if (I2C_mode == 2) {
				if (HAL_I2C_Mem_Read_DMA(&hi2c1, I2C_slave_addr, I2C_mem_addr, I2C_read_size, i2c_rx_byte, I2C_read_size) != HAL_OK) {

					osSemaphoreRelease(i2cTxSemaphoreHandle);
					if (++error_count > 3) {
						I2C_RESET();
						continue;
					}

				} else {
					error_count = 0;
					HAL_GPIO_TogglePin(LED4_GPIO_Port, LED4_Pin);
					continue;
				}
			}


			else if (I2C_mode == 3) {
				if (HAL_I2C_Slave_Transmit_IT(&hi2c1, msg.data, msg.len)
						!= HAL_OK) {

					osSemaphoreRelease(i2cTxSemaphoreHandle);
					if (++error_count > 3) {
						I2C_RESET();
						error_count = 0;
						continue;
					}
				} else {
					error_count = 0;
					HAL_GPIO_TogglePin(LED4_GPIO_Port, LED4_Pin);
					continue;
				}
			}
		}
	}
}
  /* USER CODE END StartI2CTask */
}

/* USER CODE BEGIN Header_StartLEDTask */
/**
 * @brief Function implementing the LEDTask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartLEDTask */
void StartLEDTask(void *argument)
{
  /* USER CODE BEGIN StartLEDTask */
	uint8_t wifi_enabled = 1;
	uint8_t button_prev_state = 1;  // Start as not pressed (high)

/* Infinite loop */
for (;;) {


    uint8_t button_state = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_13);

    if (button_prev_state == 1 && button_state == 0) {
      // Button just pressed (falling edge)
      wifi_enabled ^= 1;  // Toggle

      // Toggle WiFi pin and status LED
      HAL_GPIO_WritePin(GPIOA, WIFI_Pin, wifi_enabled ? GPIO_PIN_SET : GPIO_PIN_RESET);
      HAL_GPIO_WritePin(GPIOA, WIFI_LED_Pin, wifi_enabled ? GPIO_PIN_SET : GPIO_PIN_RESET);
    }

    button_prev_state = button_state;

	//HAL_GPIO_WritePin(GPIOC, POWEER_Pin, GPIO_PIN_SET);
	HAL_GPIO_TogglePin(GPIOC, POWEER_Pin);
	HAL_IWDG_Refresh(&hiwdg);


	//print_all_task_stacks();


	osDelay(100);

}
  /* USER CODE END StartLEDTask */
}

/* USER CODE BEGIN Header_StartConfigTask */
/**
 * @brief Function implementing the ConfigTask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartConfigTask */
void StartConfigTask(void *argument)
{
  /* USER CODE BEGIN StartConfigTask */

/* Infinite loop */
for (;;) {
	osEventFlagsWait(ConfigEventHandle, 0x01, osFlagsWaitAny,
	osWaitForever);

	process_command(cmd_buffer);

	HAL_UART_Receive_IT(&huart2, &uart2_rx_byte, 1);
	HAL_UART_Receive_IT(&huart3, &uart2_rx_byte, 1);
	HAL_UART_Receive_IT(&huart4, &uart2_rx_byte, 1);
	osEventFlagsClear(ConfigEventHandle, 0x01);

	osDelay(1);
}
  /* USER CODE END StartConfigTask */
}

/* USER CODE BEGIN Header_StartCOMTask */
/**
 * @brief Function implementing the COMTask thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartCOMTask */
void StartCOMTask(void *argument)
{
  /* USER CODE BEGIN StartCOMTask */
IncomingMessage msg;
static uint8_t error_count = 0;
static uint8_t error1_count = 0;
static uint8_t error2_count = 0;
/* Infinite loop */
for (;;) {
	if (osSemaphoreAcquire(uart2TxSemaphoreHandle, osWaitForever) == osOK) {
		if (osSemaphoreAcquire(uart3TxSemaphoreHandle, osWaitForever) == osOK) {
			if (osSemaphoreAcquire(uart4TxSemaphoreHandle, osWaitForever)
					== osOK) {

				if (osMessageQueueGet(protocolQueues[COM], &msg, NULL,
				osWaitForever) == osOK) {

					if (HAL_UART_Transmit_DMA(&huart2, msg.data, msg.len)
							!= HAL_OK) {

							osSemaphoreRelease(uart2TxSemaphoreHandle);

							if (++error_count > 3) {
								Error_Handler();
								error_count = 0;

							}
						} else {
						error_count = 0; // Reset counter after a successful transmission

					}
					if (HAL_UART_Transmit_DMA(&huart3, msg.data, msg.len)
							!= HAL_OK) {


							osSemaphoreRelease(uart3TxSemaphoreHandle);

							if (++error1_count > 3) {
								Error_Handler();
								error1_count = 0;
							}
						}
					 else {
						error1_count = 0; // Reset counter after a successful transmission
					}
					if (HAL_UART_Transmit_DMA(&huart4, msg.data, msg.len)
							!= HAL_OK) {
						osSemaphoreRelease(uart4TxSemaphoreHandle);

							if (++error2_count > 3) {
								Error_Handler();
								error2_count = 0;
							}

					} else {
						error2_count = 0; // Reset counter after a successful transmission
					}
					HAL_GPIO_TogglePin(COM_LED_GPIO_Port, COM_LED_Pin);
				}
			}
		}
	}
}
  /* USER CODE END StartCOMTask */
}

/**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6)
  {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
/* User can add his own implementation to report the HAL error return state */
__disable_irq();
HAL_GPIO_WritePin(WIFI_LED_GPIO_Port, WIFI_LED_Pin, GPIO_PIN_RESET);
HAL_GPIO_WritePin(WIFI_GPIO_Port, WIFI_Pin, GPIO_PIN_RESET);
HAL_GPIO_WritePin(GPIOC,
COM_LED_Pin | ERROR_Pin | POWEER_Pin | LED1_Pin | LED2_Pin | LED3_Pin,
		GPIO_PIN_RESET);
HAL_GPIO_WritePin(LED4_GPIO_Port, LED4_Pin, GPIO_PIN_RESET);
while (1) {
	HAL_GPIO_TogglePin(GPIOC, ERROR_Pin);
	for (volatile uint32_t i = 0; i < 1000000; i++)
		;
}
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */

uint8_t assert_failed_buffer[] =
		"Assert failed all perefirall will Default to Factory Settings";
if (HAL_UART_Transmit(&huart4, assert_failed_buffer,
		sizeof(assert_failed_buffer), 200) != HAL_OK) {
	Error_Handler();
}
if (HAL_UART_Transmit(&huart2, assert_failed_buffer,
		sizeof(assert_failed_buffer), 200) != HAL_OK) {
	Error_Handler();
}
MX_CAN1_Init();
MX_I2C1_Init();
MX_SPI1_Init();
MX_USART2_UART_Init();
MX_USART1_UART_Init();
MX_UART4_Init();
/* USER CODE BEGIN 2 */

CAN_Init();

HAL_UART_Receive_DMA(&huart1, uart1_rx_byte, UART_rx_size);
HAL_UART_Receive_DMA(&huart2, &uart2_rx_byte, 1);
HAL_UART_Receive_DMA(&huart3, &uart2_rx_byte, 1);
HAL_UART_Receive_DMA(&huart4, &uart2_rx_byte, 1);
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
