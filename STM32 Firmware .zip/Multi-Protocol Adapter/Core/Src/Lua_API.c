#include "Lua_API.h"


extern volatile uint8_t lua_protocol_filter[NUM_PROTOCOLS];

 int lua_read_pin(lua_State *L) {
	int pin = luaL_checkinteger(L, 1);

	if (pin != 0) {
		return luaL_error(L, "Only pin 0 is supported");
	}

	GPIO_PinState state = HAL_GPIO_ReadPin(GPIOC, GPIO_PIN_3);

	// Cast to int to ensure compatibility with Lua (in case GPIO_PinState is not 0/1)
	lua_pushinteger(L, (state == GPIO_PIN_SET) ? 1 : 0);

	return 1;  // Always return the number of pushed results
}



 int lua_spi_send(lua_State *L) {
	uint8_t tx[64] = { 0 };
	size_t len = 0;

	if (lua_type(L, 1) == LUA_TSTRING) {
		const char *str = luaL_checklstring(L, 1, &len);
		if (len > sizeof(tx))
			return luaL_error(L, "SPI: Data too long");
		memcpy(tx, str, len);
	} else if (lua_type(L, 1) == LUA_TTABLE) {
		len = lua_rawlen(L, 1);
		if (len > sizeof(tx))
			return luaL_error(L, "SPI: Table too long");

		for (size_t i = 1; i <= len; ++i) {
			lua_rawgeti(L, 1, i);
			if (!lua_isinteger(L, -1))
				return luaL_error(L, "SPI: Non-integer in table");
			tx[i - 1] = (uint8_t) lua_tointeger(L, -1);
			lua_pop(L, 1);
		}
	} else {
		return luaL_error(L, "SPI: Expected string or table");
	}

	if (HAL_SPI_Transmit(&hspi1, tx, len, 1000) != HAL_OK) {
		return luaL_error(L, "SPI send failed");
	}

	lua_pushboolean(L, 1);  // return success
	return 1;
}

 int lua_spi_transfer(lua_State *L) {
	uint8_t tx[64] = { 0 }, rx[64] = { 0 };
	size_t len = 0;

	if (lua_type(L, 1) == LUA_TSTRING) {
		const char *str = luaL_checklstring(L, 1, &len);
		if (len > sizeof(tx))
			return luaL_error(L, "SPI: Data too long");
		memcpy(tx, str, len);
	} else if (lua_type(L, 1) == LUA_TTABLE) {
		len = lua_rawlen(L, 1);
		if (len > sizeof(tx))
			return luaL_error(L, "SPI: Table too long");

		for (size_t i = 1; i <= len; ++i) {
			lua_rawgeti(L, 1, i);
			if (!lua_isinteger(L, -1))
				return luaL_error(L, "SPI: Non-integer in table");
			tx[i - 1] = (uint8_t) lua_tointeger(L, -1);
			lua_pop(L, 1);
		}
	} else {
		return luaL_error(L, "SPI: Expected string or table");
	}

	if (HAL_SPI_TransmitReceive(&hspi1, tx, rx, len, 1000) != HAL_OK) {
		return luaL_error(L, "SPI transfer failed");
	}

	// Return received data as a string
	lua_pushlstring(L, (const char*) rx, len);
	return 1;
}
 int lua_can_filter(lua_State *L) {
	uint32_t id = (uint32_t) luaL_checkinteger(L, 1);
	int extended = lua_toboolean(L, 2);  // optional, default = false

	CAN_FilterTypeDef filter = { .FilterBank = 0, .FilterMode =
			CAN_FILTERMODE_IDMASK, .FilterScale = CAN_FILTERSCALE_32BIT,
			.FilterActivation = ENABLE, .SlaveStartFilterBank = 14,
			.FilterFIFOAssignment = CAN_FILTER_FIFO0 };

	if (extended) {
		filter.FilterIdHigh = (id >> 13) & 0xFFFF;
		filter.FilterIdLow = ((id << 3) & 0xFFFF) | 0x04;  // IDE bit set
		filter.FilterMaskIdHigh = 0xFFFF;
		filter.FilterMaskIdLow = 0x0006;  // mask both RTR and IDE
	} else {
		filter.FilterIdHigh = (id << 5) & 0xFFFF;
		filter.FilterIdLow = 0x0000;
		filter.FilterMaskIdHigh = 0xFFE0;
		filter.FilterMaskIdLow = 0x0000;
	}

	if (HAL_CAN_ConfigFilter(&hcan1, &filter) != HAL_OK) {
		return luaL_error(L, "CAN filter config failed");
	}

	lua_pushboolean(L, 1);
	return 1;
}

 int lua_can_send(lua_State *L) {
	uint32_t id = (uint32_t) luaL_checkinteger(L, 1);

	uint8_t data[8] = { 0 };
	size_t len = 0;

	if (lua_type(L, 2) == LUA_TSTRING) {
		const char *str = luaL_checklstring(L, 2, &len);
		if (len > 8)
			return luaL_error(L, "CAN: Max 8 bytes");
		memcpy(data, str, len);
	} else if (lua_type(L, 2) == LUA_TTABLE) {
		len = lua_rawlen(L, 2);
		if (len > 8)
			return luaL_error(L, "CAN: Max 8 bytes");

		for (size_t i = 1; i <= len; ++i) {
			lua_rawgeti(L, 2, i);
			if (!lua_isinteger(L, -1))
				return luaL_error(L, "CAN: Non-integer");
			data[i - 1] = (uint8_t) lua_tointeger(L, -1);
			lua_pop(L, 1);
		}
	} else {
		return luaL_error(L, "CAN: Expected string or table");
	}

	CAN_TxHeaderTypeDef txHeader = { .StdId = id, .IDE = CAN_ID_STD, .RTR =
			CAN_RTR_DATA, .DLC = len };

	uint32_t mailbox;
	if (HAL_CAN_AddTxMessage(&hcan1, &txHeader, data, &mailbox) != HAL_OK) {
		return luaL_error(L, "CAN TX failed");
	}

	lua_pushboolean(L, 1);
	return 1;
}

 int lua_can_send_ext(lua_State *L) {
	uint32_t id = (uint32_t) luaL_checkinteger(L, 1);

	uint8_t data[8] = { 0 };
	size_t len = 0;

	if (lua_type(L, 2) == LUA_TSTRING) {
		const char *str = luaL_checklstring(L, 2, &len);
		if (len > 8)
			return luaL_error(L, "CAN EXT: Max 8 bytes");
		memcpy(data, str, len);
	} else if (lua_type(L, 2) == LUA_TTABLE) {
		len = lua_rawlen(L, 2);
		if (len > 8)
			return luaL_error(L, "CAN EXT: Max 8 bytes");

		for (size_t i = 1; i <= len; ++i) {
			lua_rawgeti(L, 2, i);
			if (!lua_isinteger(L, -1))
				return luaL_error(L, "CAN EXT: Non-integer");
			data[i - 1] = (uint8_t) lua_tointeger(L, -1);
			lua_pop(L, 1);
		}
	} else {
		return luaL_error(L, "CAN EXT: Expected string or table");
	}

	CAN_TxHeaderTypeDef txHeader = { .ExtId = id, .IDE = CAN_ID_EXT, .RTR =
			CAN_RTR_DATA, .DLC = len };

	uint32_t mailbox;
	if (HAL_CAN_AddTxMessage(&hcan1, &txHeader, data, &mailbox) != HAL_OK) {
		return luaL_error(L, "CAN EXT TX failed");
	}

	lua_pushboolean(L, 1);
	return 1;
}

 int lua_i2c_send(lua_State *L) {
	uint16_t address = (uint16_t) luaL_checkinteger(L, 1);

	// Prepare data
	uint8_t buffer[64];
	size_t len = 0;

	if (lua_type(L, 2) == LUA_TSTRING) {
		const char *str = luaL_checklstring(L, 2, &len);
		if (len > sizeof(buffer))
			return luaL_error(L, "DATA TOO LONG");
		memcpy(buffer, str, len);
	} else if (lua_type(L, 2) == LUA_TTABLE) {
		len = lua_rawlen(L, 2);
		if (len > sizeof(buffer))
			return luaL_error(L, "DATA TOO LONG");

		for (size_t i = 1; i <= len; ++i) {
			lua_rawgeti(L, 2, i);
			if (!lua_isinteger(L, -1))
				return luaL_error(L, "INVALID BYTE");
			buffer[i - 1] = (uint8_t) lua_tointeger(L, -1);
			lua_pop(L, 1);
		}
	} else {
		return luaL_error(L, "Expected string or table as data");
	}

	// Transmit
	if (HAL_I2C_Master_Transmit(&hi2c1, address << 1, buffer, len, 1000)
			== HAL_OK) {
		lua_pushboolean(L, 1);
	} else {
		lua_pushboolean(L, 0);
	}
	return 1;
}

 int lua_i2c_mem_write(lua_State *L) {
	uint16_t addr = (uint16_t) luaL_checkinteger(L, 1);
	uint8_t mem_addr = (uint8_t) luaL_checkinteger(L, 2);

	uint8_t buffer[64];
	size_t len = 0;

	if (lua_type(L, 3) == LUA_TSTRING) {
		const char *str = luaL_checklstring(L, 3, &len);
		if (len > sizeof(buffer))
			return luaL_error(L, "DATA TOO LONG");
		memcpy(buffer, str, len);
	} else if (lua_type(L, 3) == LUA_TTABLE) {
		len = lua_rawlen(L, 3);
		if (len > sizeof(buffer))
			return luaL_error(L, "DATA TOO LONG");

		for (size_t i = 1; i <= len; ++i) {
			lua_rawgeti(L, 3, i);
			if (!lua_isinteger(L, -1))
				return luaL_error(L, "INVALID BYTE");
			buffer[i - 1] = (uint8_t) lua_tointeger(L, -1);
			lua_pop(L, 1);
		}
	} else {
		return luaL_error(L, "Expected string or table as data");
	}

	if (HAL_I2C_Mem_Write(&hi2c1, addr << 1, mem_addr, I2C_MEMADD_SIZE_8BIT,
			buffer, len, 1000) == HAL_OK) {
		lua_pushboolean(L, 1);
	} else {
		lua_pushboolean(L, 0);
	}
	return 1;
}

 int lua_i2c_read(lua_State *L) {
	uint16_t addr = (uint16_t) luaL_checkinteger(L, 1);
	uint16_t len = (uint16_t) luaL_checkinteger(L, 2);
	if (len == 0 || len > 64)
		return luaL_error(L, "INVALID LENGTH");

	uint8_t buffer[64];
	if (HAL_I2C_Master_Receive(&hi2c1, addr << 1, buffer, len, 1000)
			== HAL_OK) {
		lua_pushlstring(L, (const char*) buffer, len);
	} else {
		lua_pushnil(L);
	}
	return 1;
}

 int lua_i2c_mem_read(lua_State *L) {
	uint16_t addr = (uint16_t) luaL_checkinteger(L, 1);
	uint8_t mem_addr = (uint8_t) luaL_checkinteger(L, 2);
	uint16_t len = (uint16_t) luaL_checkinteger(L, 3);
	if (len == 0 || len > 64)
		return luaL_error(L, "INVALID LENGTH");

	uint8_t buffer[64];
	if (HAL_I2C_Mem_Read(&hi2c1, addr << 1, mem_addr, I2C_MEMADD_SIZE_8BIT,
			buffer, len, 1000) == HAL_OK) {
		lua_pushlstring(L, (const char*) buffer, len);
	} else {
		lua_pushnil(L);
	}
	return 1;
}

 int lua_write_pin(lua_State *L) {
	int pin = luaL_checkinteger(L, 1);
	int state = luaL_checkinteger(L, 2);

	if (pin == 0) {

		HAL_GPIO_WritePin(GPIOC, GPIO_PIN_3,
				(state != 0) ? GPIO_PIN_SET : GPIO_PIN_RESET);

		return 0;

	} else {
		return luaL_error(L, "Only pin 0 is supported");

	}

}
 int lua_set_pin_mode(lua_State *L) {
	int pin = luaL_checkinteger(L, 1);
	const char *mode = luaL_checkstring(L, 2);

	if (pin != 0)
		return luaL_error(L, "Only pin 0 is supported");

	if (strcmp(mode, "out") == 0) {
		Set_Pin_Output(GPIOC, GPIO_PIN_3);
	} else if (strcmp(mode, "in") == 0) {
		Set_Pin_Input(GPIOC, GPIO_PIN_3);
	} else {
		return luaL_error(L, "Invalid mode: use \"in\" or \"out\"");
	}

	return 0;
}

 int send_message(lua_State *L) {
	ProtocolType proto = (ProtocolType) luaL_checkinteger(L, 1);
	if (proto >= NUM_PROTOCOLS) {
		lua_pushstring(L, "INVALID PROTOCOL");
		return 1;
	}

	IncomingMessage msg;
	msg.len = 0;

	// Check if second argument is a string
	if (lua_type(L, 2) == LUA_TSTRING) {
		size_t len;
		const char *data = luaL_checklstring(L, 2, &len);
		if (len > sizeof(msg.data)) {
			lua_pushstring(L, "DATA TOO LONG");
			return 1;
		}
		memcpy(msg.data, data, len);
		msg.len = len;
	}
	// Or if it's a table of integers
	else if (lua_type(L, 2) == LUA_TTABLE) {
		size_t len = lua_rawlen(L, 2);
		if (len > sizeof(msg.data)) {
			lua_pushstring(L, "TABLE TOO LONG");
			return 1;
		}

		for (size_t i = 1; i <= len; ++i) {
			lua_rawgeti(L, 2, i);
			if (!lua_isinteger(L, -1)) {
				lua_pushstring(L, "NON-INTEGER IN TABLE");
				return 1;
			}
			uint8_t value = (uint8_t) lua_tointeger(L, -1);
			msg.data[i - 1] = value;
			lua_pop(L, 1);
		}
		msg.len = len;
	} else {
		lua_pushstring(L, "INVALID DATA TYPE (NEED STRING OR TABLE)");
		return 1;
	}

	if (osMessageQueuePut(protocolQueues[proto], &msg, 0, 0) == osOK) {

	} else {
		HAL_UART_Transmit(&huart2, (uint8_t*) "QUEUEING ERR\n", 13, 200);
	}
	return 1;
}
 int lua_get(lua_State *L) {
	int n = lua_gettop(L);  // number of arguments

	// Reset filter
	memset(lua_protocol_filter, 0, sizeof(lua_protocol_filter));

	for (int i = 1; i <= n; i++) {
		if (!lua_isinteger(L, i)) {
			return luaL_error(L, "get() expects protocol integers");
		}
		int proto = lua_tointeger(L, i);
		if (proto >= 0 && proto < NUM_PROTOCOLS) {
			lua_protocol_filter[proto] = 1;
		}
	}

	return 0;
}

 int configure_system(lua_State *L) {
	const char *cmd = luaL_checkstring(L, 1);
	process_command((char*) cmd);
	lua_pushboolean(L, 1);
	return 1;
}

 int lua_print(lua_State *L) {
	int n = lua_gettop(L);  // number of arguments
//	char buffer[128];
	for (int i = 1; i <= n; i++) {
		const char *s = luaL_tolstring(L, i, NULL);  // convert to string
		if (s) {
			HAL_UART_Transmit(&huart2, (uint8_t*) s, strlen(s), HAL_MAX_DELAY);
		}
		if (i < n) {
			HAL_UART_Transmit(&huart2, (uint8_t*) " ", 1, HAL_MAX_DELAY);
		}
		lua_pop(L, 1);  // remove string copy left by luaL_tolstring
	}
	HAL_UART_Transmit(&huart2, (uint8_t*) "\n", 1, HAL_MAX_DELAY);
	return 0;
}

 int lua_delay_ms(lua_State *L) {
	uint32_t ms = luaL_checkinteger(L, 1);
	HAL_Delay(ms);

	return 0;
}
 int lua_delay_us(lua_State *L) {
	uint16_t us = luaL_checkinteger(L, 1);
	delay_us(us);
	return 0;
}
 int lua_delay_ms_NB(lua_State *L) {
	uint32_t ms = luaL_checkinteger(L, 1);
	osDelay(ms);
	return 0;
}
